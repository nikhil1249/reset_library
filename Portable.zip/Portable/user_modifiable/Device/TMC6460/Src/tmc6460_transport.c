#include "call_trace.h"
#include "tmc6460_transport.h"
#include "app_config.h"
#include "drv_tmc6460.h"

#include <stddef.h>

#define TMC6460_MAX_REGISTER_ADDRESS 0x03FFU

/* SPI framing -------------------------------------------------------------- */
#define TMC6460_SPI_FRAME_SIZE 6U
#define TMC6460_SPI_WRITE_BIT 0x80U
#define TMC6460_SPI_ADDR_HIGH_MASK 0x03U

static tmc6460_transport_status_t TMC6460_FromSpiStatus(spi_interface_status_t status)
{
    TRACE_ENTER(CT_F171);
    switch (status)
    {
    case SPI_INTERFACE_OK:
        return TMC6460_TRANSPORT_OK;
    case SPI_INTERFACE_BUSY:
        return TMC6460_TRANSPORT_BUSY;
    case SPI_INTERFACE_TIMEOUT:
        return TMC6460_TRANSPORT_TIMEOUT;
    case SPI_INTERFACE_INVALID_PARAM:
        return TMC6460_TRANSPORT_INVALID_PARAM;
    default:
        return TMC6460_TRANSPORT_ERROR;
    }
}

static void TMC6460_SPI_BuildFrame(uint16_t address, uint8_t write, uint32_t value,
                                   uint8_t frame[TMC6460_SPI_FRAME_SIZE])
{
    TRACE_ENTER(CT_F172);
    frame[0] = (uint8_t)(((write != 0U) ? TMC6460_SPI_WRITE_BIT : 0U) | ((address >> 8U) & TMC6460_SPI_ADDR_HIGH_MASK));
    frame[1] = (uint8_t)(address & 0xFFU);
    frame[2] = (uint8_t)((value >> 24U) & 0xFFU);
    frame[3] = (uint8_t)((value >> 16U) & 0xFFU);
    frame[4] = (uint8_t)((value >> 8U) & 0xFFU);
    frame[5] = (uint8_t)(value & 0xFFU);
}

static uint16_t TMC6460_SPI_ResponseAddress(const uint8_t response[TMC6460_SPI_FRAME_SIZE])
{
    TRACE_ENTER(CT_F173);
    return (uint16_t)((((uint16_t)response[0] & TMC6460_SPI_ADDR_HIGH_MASK) << 8U) | (uint16_t)response[1]);
}

static uint32_t TMC6460_SPI_ResponseData(const uint8_t response[TMC6460_SPI_FRAME_SIZE])
{
    TRACE_ENTER(CT_F174);
    return ((uint32_t)response[2] << 24U) | ((uint32_t)response[3] << 16U) | ((uint32_t)response[4] << 8U) |
           ((uint32_t)response[5]);
}

tmc6460_transport_status_t TMC6460_TransportReadRegister(uint16_t address, uint32_t *value, uint32_t timeout_ms)
{
    TRACE_ENTER(CT_F175);
    if ((value == NULL) || (address > TMC6460_MAX_REGISTER_ADDRESS))
    {
        return TMC6460_TRANSPORT_INVALID_PARAM;
    }

    {
        uint8_t request[TMC6460_SPI_FRAME_SIZE];
        uint8_t first_response[TMC6460_SPI_FRAME_SIZE];
        uint8_t read_response[TMC6460_SPI_FRAME_SIZE];
        spi_interface_status_t spi_status;

        /* SPI is pipelined: the reply to a request appears during the NEXT
         * 48-bit datagram. Send the same read request twice and use the second
         * response. Example: address 0x140 -> 01 40 00 00 00 00. */
        TMC6460_SPI_BuildFrame(address, 0U, 0U, request);

        spi_status =
            spi_interface_transfer(SPI_INTERFACE_PORT_TMC, request, first_response, sizeof(request), timeout_ms);
        if (spi_status != SPI_INTERFACE_OK)
        {
            return TMC6460_FromSpiStatus(spi_status);
        }

        spi_status =
            spi_interface_transfer(SPI_INTERFACE_PORT_TMC, request, read_response, sizeof(request), timeout_ms);
        if (spi_status != SPI_INTERFACE_OK)
        {
            return TMC6460_FromSpiStatus(spi_status);
        }

        if (TMC6460_SPI_ResponseAddress(read_response) != address)
        {
            return TMC6460_TRANSPORT_ERROR;
        }

        *value = TMC6460_SPI_ResponseData(read_response);
        return TMC6460_TRANSPORT_OK;
    }
}

tmc6460_transport_status_t TMC6460_TransportWriteRegister(uint16_t address, uint32_t value, uint32_t timeout_ms)
{
    TRACE_ENTER(CT_F176);
    if (address > TMC6460_MAX_REGISTER_ADDRESS)
    {
        return TMC6460_TRANSPORT_INVALID_PARAM;
    }

    {
        uint8_t write_request[TMC6460_SPI_FRAME_SIZE];
        uint8_t followup_read[TMC6460_SPI_FRAME_SIZE];
        uint8_t ignored_response[TMC6460_SPI_FRAME_SIZE];
        uint8_t write_response[TMC6460_SPI_FRAME_SIZE];
        spi_interface_status_t spi_status;

        /* SPI write example from the data sheet:
         * address 0x0C3, value 2 -> 80 C3 00 00 00 02. */
        TMC6460_SPI_BuildFrame(address, 1U, value, write_request);

        /* A second command is required to clock out the response to the write.
         * Use a harmless read of the same register. The response received
         * during this second frame is the read-after-write response. */
        TMC6460_SPI_BuildFrame(address, 0U, 0U, followup_read);

        spi_status = spi_interface_transfer(SPI_INTERFACE_PORT_TMC, write_request, ignored_response,
                                            sizeof(write_request), timeout_ms);
        if (spi_status != SPI_INTERFACE_OK)
        {
            return TMC6460_FromSpiStatus(spi_status);
        }

        spi_status = spi_interface_transfer(SPI_INTERFACE_PORT_TMC, followup_read, write_response,
                                            sizeof(followup_read), timeout_ms);
        if (spi_status != SPI_INTERFACE_OK)
        {
            return TMC6460_FromSpiStatus(spi_status);
        }

        if (TMC6460_SPI_ResponseAddress(write_response) != address)
        {
            return TMC6460_TRANSPORT_ERROR;
        }

        /* Do not require response data == requested value: W1C, self-clearing,
         * and hardware-modified registers can legitimately read back different
         * data immediately after a write. */
        return TMC6460_TRANSPORT_OK;
    }
}
