Keep baseline security, boot confirmation and memory-map files unchanged. No security implementation is supplied by this migration.
