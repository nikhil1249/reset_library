#include "actuator_sr.h"
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
#include "actuator_end_detection.h"
#include "actuator_calibration_config.h"
#include "actuator_soft_stall_config.h"
#include "drv_uart.h"
#include <limits.h>
#include <stdio.h>
#include <string.h>

/* No SR heap allocation, extra task, or independent peripheral owner. */
static struct
{
    tmc6460_motor_t *motor;
    tmc6460_motor_profile_t profile;
    actuator_sr_state_t state;
    volatile bool stop_requested;
    int32_t zero, ninety, position, previous, leg_start;
    uint32_t stroke, contact_count, position_count;
    TickType_t started;
} s_sr;

_Static_assert(SR_STARTUP_PROFILE >= ACTUATOR_TYPE_10KG && SR_STARTUP_PROFILE < ACTUATOR_TYPE_COUNT,
               "Invalid SR startup profile");
_Static_assert(SR_SAMPLE_RATE_HZ > 0 && 1000U % SR_SAMPLE_RATE_HZ == 0, "SR sample rate must divide the 1 kHz tick");

/* V/W select hard-end testing. X/Y select soft-end testing.
 * STALL_MODE selects the G calibration contact policy only. */
static bool sr_hard_end(void)
{
    return s_sr.state == SR_MANUAL_CW || s_sr.state == SR_MANUAL_CCW ||
           ((s_sr.state == SR_CAL_CW || s_sr.state == SR_CAL_CCW) && STALL_MODE == STALL_MODE_HARD);
}

static bool sr_calibrating(void)
{
    return s_sr.state == SR_CAL_CW || s_sr.state == SR_CAL_CCW;
}
static bool sr_moving_cw(void)
{
    return s_sr.state == SR_CAL_CW || s_sr.state == SR_RUN_CW || s_sr.state == SR_REFERENCE_CW ||
           s_sr.state == SR_MANUAL_CW;
}
static bool sr_moving(void)
{
    return sr_moving_cw() || s_sr.state == SR_CAL_CCW || s_sr.state == SR_RUN_CCW || s_sr.state == SR_MANUAL_CCW;
}

static void sr_set_state(actuator_sr_state_t state)
{
    s_sr.state = state;
    g_status.sr_state = (uint32_t)state;
    g_status.motor_state = state == SR_FAULT                                                        ? MOTOR_STATE_ERROR
                           : sr_moving_cw()                                                         ? MOTOR_STATE_CW
                           : (state == SR_CAL_CCW || state == SR_RUN_CCW || state == SR_MANUAL_CCW) ? MOTOR_STATE_CCW
                                                                                                    : MOTOR_STATE_HOLD;
}

/* These two predicates are the only normal endpoint decisions. Future
 * potentiometer checks belong here, ANDed with the current position/contact
 * decision. Acquisition/timeout faults must remain independent of endpoints. */
static bool actuator_zero_end_reached(void)
{
    return (int64_t)s_sr.position <= (int64_t)s_sr.zero;
}

static bool actuator_90_contact_armed(void)
{
    if (!sr_hard_end() && g_status.position_reference_valid && s_sr.stroke != 0U)
    {
        return ((int64_t)s_sr.position - s_sr.zero) * (int64_t)PERCENT_X100_SCALE >=
               (int64_t)s_sr.stroke * ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100;
    }
    return true;
}

static bool sr_contact_confirmed(void)
{
    uint32_t confirm_ms, position_ms;
    if (sr_hard_end())
    {
        confirm_ms = ACTUATOR_CALIBRATION_STALL_CONFIRM_MS;
        position_ms = ACTUATOR_CALIBRATION_POSITION_ONLY_CONFIRM_MS;
    }
    else if (g_status.position_reference_valid && s_sr.stroke != 0U)
    {
        confirm_ms = ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS;
        position_ms = ACTUATOR_SOFT_STALL_POSITION_ONLY_CONFIRM_MS;
    }
    else
    {
        confirm_ms = ACTUATOR_SOFT_STALL_REFERENCE_CONTACT_CONFIRM_MS;
        position_ms = ACTUATOR_SOFT_STALL_REFERENCE_POSITION_ONLY_MS;
    }
    return actuator_90_contact_armed() &&
           (s_sr.contact_count >=
                (confirm_ms * SR_SAMPLE_RATE_HZ + MILLISECONDS_PER_SECOND - 1U) / MILLISECONDS_PER_SECOND ||
            s_sr.position_count >=
                (position_ms * SR_SAMPLE_RATE_HZ + MILLISECONDS_PER_SECOND - 1U) / MILLISECONDS_PER_SECOND);
}

static bool actuator_90_end_reached(void)
{
    return sr_contact_confirmed();
}

static void sr_update_position(int32_t position)
{
    s_sr.position = position;
    g_status.position_raw = position;
    g_status.position_sample_count++;
    if (s_sr.stroke != 0U && g_status.position_reference_valid)
    {
        int64_t angle = ((int64_t)position - s_sr.zero) * (int64_t)ACTUATOR_FULL_TRAVEL_DEG_X100 / s_sr.stroke;
        g_status.angle_deg_x100 = angle > INT32_MAX ? INT32_MAX : angle < INT32_MIN ? INT32_MIN : (int32_t)angle;
    }
}

static bool sr_stop(actuator_sr_state_t next, actuator_sr_error_t reason)
{
    tmc6460_status_t status = TMC6460_OK;
    tmc6460_status_t cause = g_status.tmc_status;
    if (s_sr.motor->initialized)
    {
        /* Preserve the TMC stop/hold sequence; never zero torque/flux targets. */
        for (unsigned attempt = 0; attempt < SR_STOP_ATTEMPTS; ++attempt)
        {
            /* Only release the active control loop at a trusted spring-rest zero.
             * Loaded/intermediate positions retain the proven powered HOLD. */
            bool zero_rest = reason == SR_ERROR_NONE && s_sr.stroke != 0U &&
                             (g_status.position_reference_valid || s_sr.state == SR_CAL_CCW) &&
                             actuator_zero_end_reached();
            status = zero_rest ? TMC6460_MotorStopIdle(s_sr.motor) : TMC6460_MotorStopHold(s_sr.motor);
            if (status == TMC6460_OK)
            {
                break;
            }
            if (attempt + 1U < SR_STOP_ATTEMPTS)
            {
                vTaskDelay(pdMS_TO_TICKS(SR_STOP_RETRY_MS));
            }
        }
    }
    g_status.tmc_status = reason == SR_ERROR_TMC && status == TMC6460_OK ? cause : status;
    if (status != TMC6460_OK)
    {
        reason = SR_ERROR_STOP;
        next = SR_FAULT;
    }
    g_status.sr_error = (uint32_t)reason;
    if (reason != SR_ERROR_NONE)
    {
        g_status.command_error_count++;
    }
    g_status.commanded_velocity_raw = status == TMC6460_OK ? 0 : s_sr.motor->commanded_velocity_raw;
    sr_set_state(next);
    if (next == SR_FAULT)
    {
        drv_debug_write_text("SR FAULT: inspect R; correct cause, Z then A/B/C to reinitialize\r\n");
    }
    return status == TMC6460_OK;
}

static bool sr_read_position(void)
{
    int32_t position;
    tmc6460_status_t status = TMC6460_MotorReadPosition(s_sr.motor, &position);
    g_status.tmc_status = status;
    if (status != TMC6460_OK)
    {
        g_status.position_error_count++;
        (void)sr_stop(SR_FAULT, SR_ERROR_TMC);
        return false;
    }
    sr_update_position(position);
    return true;
}

static void sr_begin(actuator_sr_state_t state)
{
    bool cw = state == SR_CAL_CW || state == SR_RUN_CW || state == SR_REFERENCE_CW || state == SR_MANUAL_CW;
    int32_t torque = cw ? SR_CW_TORQUE_LIMIT_RAW : SR_CCW_TORQUE_LIMIT_RAW;
    tmc6460_status_t status;
    if (s_sr.stop_requested)
    {
        return;
    }
    if (torque == 0)
    {
        torque = ActuatorProfile_Get(g_status.actuator_type)->motor.run_torque_flux_limit_raw;
    }
    s_sr.profile.run_torque_flux_limit_raw = torque;
    s_sr.leg_start = s_sr.previous = s_sr.position;
    s_sr.contact_count = s_sr.position_count = 0;
    status = TMC6460_MotorSetVelocity(s_sr.motor, cw ? SR_RUN_VELOCITY_RAW : -SR_RUN_VELOCITY_RAW);
    g_status.tmc_status = status;
    if (status != TMC6460_OK)
    {
        (void)sr_stop(SR_FAULT, SR_ERROR_TMC);
        return;
    }
    s_sr.started = xTaskGetTickCount();
    sr_set_state(state);
    g_status.commanded_velocity_raw = cw ? SR_RUN_VELOCITY_RAW : -SR_RUN_VELOCITY_RAW;
}

void ActuatorSR_Init(tmc6460_motor_t *motor)
{
    memset(&s_sr, 0, sizeof(s_sr));
    s_sr.motor = motor;
    g_status.actuator_type = SR_STARTUP_PROFILE;
    sr_set_state(SR_BOOT);
}

bool ActuatorSR_IsReady(void)
{
    return s_sr.state == SR_READY && g_status.calibration_valid && !s_sr.stop_requested;
}

void ActuatorSR_RequestStop(void)
{
    s_sr.stop_requested = true;
}

/* Debug task may call this cached diagnostic; it never touches the motor. */
void ActuatorSR_PrintStatus(void)
{
    char line[144];
    (void)snprintf(line, sizeof(line), "SR state=%lu err=%lu tmc=%u pos=%ld zero=%ld span=%lu\r\n",
                   (unsigned long)g_status.sr_state, (unsigned long)g_status.sr_error, (unsigned)g_status.tmc_status,
                   (long)g_status.position_raw, (long)g_status.reference_zero_raw,
                   (unsigned long)g_status.calibration_stroke_counts);
    drv_debug_write_text(line);
}

/* G replaces the learned span. Manual motion only invalidates its raw anchor. */
static void sr_clear_calibration(void)
{
    s_sr.stroke = 0U;
    g_status.calibration_valid = g_status.calibration_params_loaded = 0U;
    g_status.position_reference_valid = 0U;
    g_status.calibration_stroke_counts = 0U;
    g_status.calibration_stroke_signed_counts = 0;
}

static void sr_select_profile(actuator_type_t type)
{
    const actuator_profile_t *profile = ActuatorProfile_Get(type);
    uint32_t chip_id = 0U;
    tmc6460_status_t status;
    if (profile == NULL)
    {
        (void)sr_stop(SR_FAULT, SR_ERROR_CONFIG);
        return;
    }
    /* Do not discard an initialized context until HOLD is confirmed. */
    if (!sr_stop(SR_READY, SR_ERROR_NONE))
    {
        return;
    }
    bool preserve = g_status.calibration_valid && g_status.actuator_type == type;
    if (!preserve)
    {
        sr_clear_calibration();
    }
    else
    {
        g_status.position_reference_valid = 0U;
    }
    s_sr.profile = profile->motor;
    if (s_sr.profile.maximum_velocity_raw < SR_RUN_VELOCITY_RAW)
    {
        s_sr.profile.maximum_velocity_raw = SR_RUN_VELOCITY_RAW;
    }
    status = TMC6460_MotorConfigure(s_sr.motor, &s_sr.profile, TMC_EXPECTED_CHIP_ID, &chip_id);
    g_status.tmc_chip_id = chip_id;
    g_status.tmc_status = status;
    g_status.actuator_initialized = status == TMC6460_OK;
    if (status != TMC6460_OK)
    {
        (void)sr_stop(SR_FAULT, SR_ERROR_TMC);
        return;
    }
    g_status.actuator_type = type;
    if (!sr_read_position())
    {
        return;
    }
    sr_set_state(SR_READY);
    drv_debug_write_text(preserve ? "SR: profile ready; span retained\r\n"
                                  : "SR: profile ready; G from physical zero\r\n");
}

void ActuatorSR_Command(motor_command_type_t command, actuator_type_t profile)
{
    g_status.command_count++;
    if (command == MOTOR_COMMAND_STOP_HOLD)
    {
        ActuatorSR_RequestStop();
        return;
    }
    /* UART output must not delay position polling while moving. */
    if (s_sr.stop_requested || sr_calibrating())
    {
        return;
    }
    bool motion_command = command == MOTOR_COMMAND_RUN_CW || command == MOTOR_COMMAND_RUN_CCW ||
                          command == MOTOR_COMMAND_SOFT_CW || command == MOTOR_COMMAND_SOFT_CCW;
    if (sr_moving())
    {
        if (!motion_command)
        {
            return;
        }
        if ((command == MOTOR_COMMAND_SOFT_CW || command == MOTOR_COMMAND_SOFT_CCW) && !g_status.calibration_valid)
        {
            return;
        }
        if (!sr_read_position() || !sr_stop(SR_READY, SR_ERROR_NONE))
        {
            return;
        }
    }
    if (command == MOTOR_COMMAND_REFRESH_DIAGNOSTICS)
    {
        ActuatorSR_PrintStatus();
        return;
    }
    if (command == MOTOR_COMMAND_SELECT_PROFILE)
    {
        sr_select_profile(profile);
        return;
    }
    if (s_sr.state == SR_FAULT || !g_status.actuator_initialized)
    {
        drv_debug_write_text("SR: select A/B/C first; inspect R if faulted\r\n");
        return;
    }
    if (command == MOTOR_COMMAND_AUTO_CALIBRATE)
    {
        /* G is the operator's confirmation that the output is physically zero.
         * Encoder position alone cannot prove zero after raw manual free-spin. */
        if (!sr_read_position())
        {
            return;
        }
        sr_clear_calibration();
        s_sr.zero = s_sr.position;
        g_status.reference_zero_raw = s_sr.zero;
        g_status.sr_error = SR_ERROR_NONE;
        drv_debug_write_text("SR CAL: confirmed physical zero captured; CW to 90\r\n");
        sr_begin(SR_CAL_CW);
        return;
    }
    if (command == MOTOR_COMMAND_RUN_CW || command == MOTOR_COMMAND_RUN_CCW)
    {
        if (!sr_read_position())
        {
            return;
        }
        /* W may free-spin at zero. Keep the measured span, but require a
         * CW reference contact before count-based operation is used again. */
        g_status.position_reference_valid = 0U;
        g_status.sr_error = SR_ERROR_NONE;
        sr_begin(command == MOTOR_COMMAND_RUN_CW ? SR_MANUAL_CW : SR_MANUAL_CCW);
        return;
    }
    if (!ActuatorSR_IsReady() || (command != MOTOR_COMMAND_SOFT_CW && command != MOTOR_COMMAND_SOFT_CCW))
    {
        drv_debug_write_text("SR: X/Y locked; complete G from physical zero first\r\n");
        return;
    }
    if (!sr_read_position())
    {
        return;
    }
    if (!g_status.position_reference_valid)
    {
        sr_begin(command == MOTOR_COMMAND_SOFT_CCW ? SR_REFERENCE_CW : SR_RUN_CW);
        return;
    }
    if (command == MOTOR_COMMAND_SOFT_CCW && actuator_zero_end_reached())
    {
        (void)sr_stop(SR_READY, SR_ERROR_NONE);
        return;
    }
    sr_begin(command == MOTOR_COMMAND_SOFT_CW ? SR_RUN_CW : SR_RUN_CCW);
}

void ActuatorSR_Poll(void)
{
    tmc6460_status_t status;
    tmc6460_motion_sample_t sample;
    TickType_t now;
    bool calibration;
    bool hard = sr_hard_end();
    int32_t position_delta =
        hard ? ACTUATOR_CALIBRATION_POSITION_DELTA_COUNTS : ACTUATOR_SOFT_STALL_POSITION_DELTA_COUNTS;
    uint32_t blank_ms =
        hard ? ACTUATOR_CALIBRATION_STARTUP_BLANKING_MS : ACTUATOR_SOFT_STALL_REFERENCE_STARTUP_BLANKING_MS;
    int32_t velocity_percent =
        hard ? ACTUATOR_CALIBRATION_VELOCITY_STOP_PERCENT : ACTUATOR_SOFT_STALL_VELOCITY_STOP_PERCENT;
    int32_t velocity_min =
        hard ? ACTUATOR_CALIBRATION_VELOCITY_STOP_MIN_RAW : ACTUATOR_SOFT_STALL_VELOCITY_STOP_MIN_RAW;
    g_status.motor_stack_min_free_words = uxTaskGetStackHighWaterMark(NULL);
    g_status.motor_stack_margin_low = g_status.motor_stack_min_free_words < TASK_TMC6460_STACK_WARN_WORDS;
    if (s_sr.stop_requested)
    {
        s_sr.stop_requested = false;
        calibration = sr_calibrating();
        if (calibration)
        {
            sr_clear_calibration();
        }
        (void)sr_stop(s_sr.state == SR_FAULT          ? SR_FAULT
                      : g_status.actuator_initialized ? SR_READY
                                                      : SR_BOOT,
                      calibration ? SR_ERROR_ABORTED_CALIBRATION : (actuator_sr_error_t)g_status.sr_error);
        return;
    }
    if (!sr_moving())
    {
        return;
    }
    now = xTaskGetTickCount();
    if ((now - s_sr.started) >=
        pdMS_TO_TICKS(sr_hard_end() ? ACTUATOR_CALIBRATION_MAX_LEG_TIME_MS : SR_SOFT_MAX_MOVE_TIME_MS))
    {
        (void)sr_stop(SR_FAULT, SR_ERROR_TIMEOUT);
        return;
    }
    if (!sr_moving_cw() && s_sr.state != SR_MANUAL_CCW)
    {
        /* Position comes first: no extra velocity/torque reads before stop. */
        if (!sr_read_position())
        {
            return;
        }
        if (s_sr.state != SR_MANUAL_CCW && actuator_zero_end_reached())
        {
            calibration = s_sr.state == SR_CAL_CCW;
            if (sr_stop(SR_READY, SR_ERROR_NONE) && calibration)
            {
                g_status.calibration_valid = g_status.calibration_params_loaded = 1U;
                g_status.position_reference_valid = 1U;
                drv_debug_write_text("SR CAL COMPLETE: zero reached, IDLE\r\n");
            }
            return;
        }
        if ((int64_t)s_sr.position - s_sr.leg_start > position_delta)
        {
            (void)sr_stop(SR_FAULT, SR_ERROR_DIRECTION);
        }
        return;
    }
    status = TMC6460_MotorReadMotionSample(s_sr.motor, &sample);
    g_status.tmc_status = status;
    if (status != TMC6460_OK)
    {
        (void)sr_stop(SR_FAULT, SR_ERROR_TMC);
        return;
    }
    sr_update_position(sample.position_raw);
    g_status.velocity_actual_raw = sample.velocity_raw;
    g_status.torque_actual_raw = sample.torque_raw;
    int64_t leg_delta = (int64_t)s_sr.position - s_sr.leg_start;
    if (sr_moving_cw() ? leg_delta < -position_delta : leg_delta > position_delta)
    {
        (void)sr_stop(SR_FAULT, SR_ERROR_DIRECTION);
        return;
    }
    if ((now - s_sr.started) >= pdMS_TO_TICKS(blank_ms))
    {
        int64_t delta = (int64_t)s_sr.position - s_sr.previous;
        int64_t velocity = sample.velocity_raw;
        int64_t threshold = (int64_t)SR_RUN_VELOCITY_RAW * velocity_percent / PERCENT_SCALE;
        bool armed = actuator_90_contact_armed();
        if (threshold < velocity_min)
        {
            threshold = velocity_min;
        }
        bool stable = delta >= -position_delta && delta <= position_delta;
        bool slow = velocity >= -threshold && velocity <= threshold;
        ActuatorEnd_Count(&s_sr.contact_count, &s_sr.position_count, armed && stable, armed && stable && slow);
    }
    s_sr.previous = s_sr.position;
    if (s_sr.state == SR_MANUAL_CCW)
    {
        /* W has no zero-count stop; a genuine motor stall still ends the test. */
        if (sr_contact_confirmed())
        {
            (void)sr_stop(SR_READY, SR_ERROR_NONE);
        }
        return;
    }
    if (actuator_90_end_reached())
    {
        if (s_sr.state == SR_MANUAL_CW)
        {
            /* A hard-stall test is not proof of the calibrated endpoint. */
            (void)sr_stop(SR_READY, SR_ERROR_NONE);
            return;
        }
        bool return_to_zero = s_sr.state == SR_REFERENCE_CW;
        int64_t stroke = (int64_t)s_sr.position - s_sr.zero;
        calibration = s_sr.state == SR_CAL_CW;
        if (calibration && (stroke < SR_MIN_TRAVEL_COUNTS || stroke > INT32_MAX))
        {
            (void)sr_stop(SR_FAULT, SR_ERROR_NO_TRAVEL);
            return;
        }
        if (!sr_stop(calibration ? SR_CAL_CCW : SR_READY, SR_ERROR_NONE))
        {
            return;
        }
        if (calibration)
        {
            s_sr.stroke = (uint32_t)stroke;
        }
        /* Re-anchor only at the loaded CW mechanical end, never at free-spin zero. */
        stroke = (int64_t)s_sr.position - s_sr.stroke;
        if (stroke < INT32_MIN || stroke > INT32_MAX)
        {
            (void)sr_stop(SR_FAULT, SR_ERROR_DIRECTION);
            return;
        }
        s_sr.ninety = s_sr.position;
        s_sr.zero = (int32_t)stroke;
        g_status.reference_zero_raw = g_status.calibration_zero_raw = s_sr.zero;
        g_status.reference_ninety_raw = g_status.calibration_ninety_raw = s_sr.ninety;
        g_status.calibration_stroke_counts = s_sr.stroke;
        g_status.calibration_stroke_signed_counts = (int32_t)s_sr.stroke;
        g_status.position_reference_valid = 1U;
        if (calibration)
        {
            sr_begin(SR_CAL_CCW);
        }
        else if (return_to_zero)
        {
            sr_begin(SR_RUN_CCW);
        }
        return;
    }
    if (!hard && g_status.position_reference_valid && s_sr.stroke != 0U)
    {
        int64_t margin = (int64_t)s_sr.stroke * ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100 / PERCENT_X100_SCALE;
        if (margin < ACTUATOR_SOFT_STALL_ENDPOINT_TOLERANCE_COUNTS)
        {
            margin = ACTUATOR_SOFT_STALL_ENDPOINT_TOLERANCE_COUNTS;
        }
        if ((int64_t)s_sr.position >= (int64_t)s_sr.ninety + margin)
        {
            (void)sr_stop(SR_FAULT, SR_ERROR_OVERSHOOT);
        }
    }
}
#endif
