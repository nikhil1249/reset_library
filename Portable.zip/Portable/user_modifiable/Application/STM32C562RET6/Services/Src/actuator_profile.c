#include "actuator_profile.h"

#include <stddef.h>

static const actuator_profile_t s_profiles[ACTUATOR_TYPE_COUNT] = {
    {ACTUATOR_TYPE_10KG,
     'A',
     "10 kg",
     {.run_torque_flux_limit_raw = ACTUATOR_10KG_RUN_TORQUE_RAW,
      .hold_torque_flux_limit_raw = ACTUATOR_10KG_HOLD_TORQUE_RAW,
      .maximum_torque_flux_limit_raw = ACTUATOR_10KG_MAX_TORQUE_RAW,
      .default_velocity_raw = ACTUATOR_10KG_DEFAULT_VELOCITY_RAW,
      .maximum_velocity_raw = ACTUATOR_10KG_MAX_VELOCITY_RAW}},
    {ACTUATOR_TYPE_20KG,
     'B',
     "20 kg",
     {.run_torque_flux_limit_raw = ACTUATOR_20KG_RUN_TORQUE_RAW,
      .hold_torque_flux_limit_raw = ACTUATOR_20KG_HOLD_TORQUE_RAW,
      .maximum_torque_flux_limit_raw = ACTUATOR_20KG_MAX_TORQUE_RAW,
      .default_velocity_raw = ACTUATOR_20KG_DEFAULT_VELOCITY_RAW,
      .maximum_velocity_raw = ACTUATOR_20KG_MAX_VELOCITY_RAW}},
    {ACTUATOR_TYPE_35KG,
     'C',
     "35 kg",
     {.run_torque_flux_limit_raw = ACTUATOR_35KG_RUN_TORQUE_RAW,
      .hold_torque_flux_limit_raw = ACTUATOR_35KG_HOLD_TORQUE_RAW,
      .maximum_torque_flux_limit_raw = ACTUATOR_35KG_MAX_TORQUE_RAW,
      .default_velocity_raw = ACTUATOR_35KG_DEFAULT_VELOCITY_RAW,
      .maximum_velocity_raw = ACTUATOR_35KG_MAX_VELOCITY_RAW}}};

const actuator_profile_t *ActuatorProfile_Get(actuator_type_t type)
{
    if ((uint32_t)type >= (uint32_t)ACTUATOR_TYPE_COUNT)
    {
        return NULL;
    }

    return &s_profiles[(uint32_t)type];
}

const actuator_profile_t *ActuatorProfile_FromCommand(char command)
{
    uint32_t i;

    if ((command >= 'a') && (command <= 'z'))
    {
        command = (char)(command - ('a' - 'A'));
    }

    for (i = 0U; i < (uint32_t)ACTUATOR_TYPE_COUNT; i++)
    {
        if (s_profiles[i].command_key == command)
        {
            return &s_profiles[i];
        }
    }

    return NULL;
}
