#include "call_trace.h"
#include "actuator_profile.h"

#include <stddef.h>

static const actuator_profile_t s_profiles[ACTUATOR_TYPE_COUNT] = {
    {ACTUATOR_TYPE_10KG,
     'A',
     "10 kg",
     {.run_torque_flux_limit_raw = ACTUATOR_10KG_RUN_TORQUE_RAW,
      .hold_torque_flux_limit_raw = ACTUATOR_10KG_HOLD_TORQUE_RAW,
      .maximum_torque_flux_limit_raw = 1200,
      .default_velocity_raw = 9000000,
      .maximum_velocity_raw = 9000000}},
    {ACTUATOR_TYPE_20KG,
     'B',
     "20 kg",
     {.run_torque_flux_limit_raw = ACTUATOR_20KG_RUN_TORQUE_RAW,
      .hold_torque_flux_limit_raw = ACTUATOR_20KG_HOLD_TORQUE_RAW,
      .maximum_torque_flux_limit_raw = 2000,
      .default_velocity_raw = 1000000,
      .maximum_velocity_raw = 1500000}},
    {ACTUATOR_TYPE_35KG,
     'C',
     "35 kg",
     {.run_torque_flux_limit_raw = ACTUATOR_35KG_RUN_TORQUE_RAW,
      .hold_torque_flux_limit_raw = ACTUATOR_35KG_HOLD_TORQUE_RAW,
      .maximum_torque_flux_limit_raw = 2500,
      .default_velocity_raw = 1000000,
      .maximum_velocity_raw = 1500000}}};

const actuator_profile_t *ActuatorProfile_Get(actuator_type_t type)
{
    TRACE_ENTER(CT_F049);
    if ((uint32_t)type >= (uint32_t)ACTUATOR_TYPE_COUNT)
    {
        return NULL;
    }

    return &s_profiles[(uint32_t)type];
}

const actuator_profile_t *ActuatorProfile_FromCommand(char command)
{
    TRACE_ENTER(CT_F050);
    uint32_t i;

    if ((command >= 'a') && (command <= 'z'))
    {
        command = (char)(command - ('a' - 'A'));
    }

    for (i = 0U; i < (uint32_t)ACTUATOR_TYPE_COUNT; i++)
    {
        if (s_profiles[i].command_key == command)
        {
            return &s_profiles[i];
        }
    }

    return NULL;
}
