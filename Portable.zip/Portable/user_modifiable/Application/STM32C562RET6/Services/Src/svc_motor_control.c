#include "call_trace.h"
#include "svc_motor_control.h"
#include "actuator_sr.h"
#include "actuator_calibration.h"
#include "actuator_soft_stall.h"
#include "actuator_reference.h"
#include "app_config.h"
#include "tmc6460_motor.h"
#include "drv_uart.h"
#include "runtime_memory.h"

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"

#if TMC_POSITION_SAMPLE_RATE_HZ == 0 || TMC_POSITION_SAMPLE_RATE_HZ > 1000U
#error "Position sampling must be between 1 and 1000 Hz"
#endif
_Static_assert(configTICK_RATE_HZ == 1000U, "Configure the 1 kHz RTOS tick in CubeMX2");
#include <stdio.h>
#include <string.h>

#define FEEDBACK_REFRESH_POSITION_SAMPLES 256U

/* Return the next RTOS period for a requested sample rate that is not an
 * integer divisor of the RTOS tick. At 1000 Hz tick / 400 Hz sampling this
 * produces 2,3,2,3,... ticks, i.e. 2.5 ms average. */
TickType_t svc_motor_control_sample_period(uint32_t *phase)
{
    TRACE_ENTER(CT_F100);
    uint32_t total;
    TickType_t ticks;

    if (phase == NULL)
    {
        return (TickType_t)1U;
    }

    total = *phase + configTICK_RATE_HZ;
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
    ticks = (TickType_t)(total / SR_SAMPLE_RATE_HZ);
    *phase = total % SR_SAMPLE_RATE_HZ;
#else
    ticks = (TickType_t)(total / TMC_POSITION_SAMPLE_RATE_HZ);
    *phase = total % TMC_POSITION_SAMPLE_RATE_HZ;
#endif

    if (ticks == (TickType_t)0U)
    {
        ticks = (TickType_t)1U;
    }

    return ticks;
}

typedef struct
{
    motor_command_type_t type;
    actuator_type_t actuator_type;
} motor_command_t;

static tmc6460_t s_tmc_device;
static tmc6460_motor_t s_motor;
static QueueHandle_t s_motor_command_queue;

volatile actuator_status_t g_status = {0};
volatile uint32_t g_stack_overflow_detected = 0U;
volatile TaskHandle_t g_stack_overflow_task = NULL;

#if ACTUATOR_TYPE == ACTUATOR_TYPE_NSR
#if ACTUATOR_NSR_AUTO_CALIBRATION
static actuator_calibration_result_t s_calibration_result;
#endif
static actuator_reference_t s_actuator_reference;

#if ACTUATOR_NSR_AUTO_CALIBRATION
static volatile uint8_t s_calibration_abort_requested = 0U;
#endif

#if ACTUATOR_NSR_SOFT_STALL
static actuator_soft_stall_result_t s_soft_stall_result;

static volatile uint8_t s_soft_stall_abort_requested = 0U;
#endif

/* FreeRTOS stack-overflow diagnostics. configCHECK_FOR_STACK_OVERFLOW=2. */

/* Do not place a large printf buffer on the MotorService task stack. The soft
 * progress callback is called synchronously from the high-priority motor task.
 * It is the only writer of this buffer, so static storage is safe here. */

#if ACTUATOR_NSR_SOFT_STALL
static char s_soft_progress_message[280];
#endif

#if ACTUATOR_NSR_AUTO_CALIBRATION
static char s_cal_progress_message[192];

static char s_cal_define_message[256];
#endif

static void update_motor_stack_watermark(void)
{
    TRACE_ENTER(CT_F101);
    UBaseType_t stack_free_words = uxTaskGetStackHighWaterMark(NULL);

    g_status.motor_stack_min_free_words = (uint32_t)stack_free_words;
    g_status.motor_stack_margin_low = (stack_free_words < (UBaseType_t)TASK_TMC6460_STACK_WARN_WORDS) ? 1U : 0U;
}

static void update_angle_from_position(int32_t position_raw)
{
    TRACE_ENTER(CT_F102);
    if (s_actuator_reference.runtime_anchor_valid != 0U)
    {
        g_status.angle_deg_x100 = ActuatorReference_PositionToDegX100(&s_actuator_reference, position_raw);
    }
    else
    {
        g_status.angle_deg_x100 = 0;
    }
}

#if ACTUATOR_NSR_AUTO_CALIBRATION || ACTUATOR_NSR_SOFT_STALL
static void update_reference_status(void)
{
    TRACE_ENTER(CT_F103);
    g_status.calibration_params_loaded = s_actuator_reference.calibration_available;
    g_status.position_reference_valid = s_actuator_reference.runtime_anchor_valid;
    g_status.reference_zero_raw = s_actuator_reference.runtime_zero_raw;
    g_status.reference_ninety_raw = s_actuator_reference.runtime_ninety_raw;

    g_status.calibration_valid = s_actuator_reference.calibration_available;
    g_status.calibration_stroke_counts = s_actuator_reference.stroke_counts;

    if (s_actuator_reference.runtime_anchor_valid != 0U)
    {
        g_status.calibration_zero_raw = s_actuator_reference.runtime_zero_raw;
        g_status.calibration_ninety_raw = s_actuator_reference.runtime_ninety_raw;
        g_status.calibration_stroke_signed_counts =
            s_actuator_reference.direction_sign * (int32_t)s_actuator_reference.stroke_counts;
    }
}

#endif
static void set_command_result(tmc6460_status_t status, motor_state_t success_state, int32_t commanded_velocity)
{
    TRACE_ENTER(CT_F104);
    taskENTER_CRITICAL();
    g_status.tmc_status = status;
    g_status.command_count++;

    if (status == TMC6460_OK)
    {
        g_status.motor_state = success_state;
        g_status.commanded_velocity_raw = commanded_velocity;
    }
    else
    {
        g_status.motor_state = MOTOR_STATE_ERROR;
        g_status.command_error_count++;
    }
    taskEXIT_CRITICAL();
}

static tmc6460_status_t refresh_tmc_feedback(void)
{
    TRACE_ENTER(CT_F105);
    tmc6460_feedback_t feedback;
    tmc6460_status_t status;

    memset(&feedback, 0, sizeof(feedback));
    status = TMC6460_MotorReadFeedback(&s_motor, &feedback);

    taskENTER_CRITICAL();
    g_status.tmc_status = status;
    if (status == TMC6460_OK)
    {
        g_status.chip_status_flags = feedback.chip_status_flags;
        g_status.chip_events = feedback.chip_events;
        g_status.gate_driver_config = feedback.gate_driver_config;
        g_status.motor_motion_config = feedback.motor_motion_config;
        g_status.feedback_output_config = feedback.feedback_output_config;
        g_status.chip_inputs_raw = feedback.chip_inputs_raw;
        g_status.hall_raw = feedback.hall_raw;
        g_status.hall_logic = feedback.hall_logic;
        g_status.hall_count = feedback.hall_count;
        g_status.hall_events = feedback.hall_events;
        g_status.feedback_ch_b_raw = feedback.feedback_ch_b_raw;
        g_status.phi_e_raw = feedback.phi_e_raw;
        g_status.velocity_target_readback_raw = feedback.velocity_target_raw;
        g_status.velocity_actual_raw = feedback.velocity_actual_raw;
        g_status.position_raw = feedback.position_actual_raw;
        g_status.torque_actual_raw = feedback.torque_actual_raw;
        g_status.flux_actual_raw = feedback.flux_actual_raw;
        update_angle_from_position(feedback.position_actual_raw);
    }
    else
    {
        g_status.diagnostic_error_count++;
    }
    taskEXIT_CRITICAL();

    return status;
}

#if ACTUATOR_NSR_AUTO_CALIBRATION
static void print_calibration_defines(const actuator_profile_t *profile, const actuator_calibration_result_t *result)
{
    TRACE_ENTER(CT_F106);
    char *message = s_cal_define_message;
    const char *prefix;

    if ((profile == NULL) || (result == NULL) || (result->valid == 0U))
    {
        return;
    }

    switch (profile->type)
    {
    case ACTUATOR_TYPE_10KG:
        prefix = "10KG";
        break;

    case ACTUATOR_TYPE_20KG:
        prefix = "20KG";
        break;

    case ACTUATOR_TYPE_35KG:
        prefix = "35KG";
        break;

    default:
        prefix = "UNKNOWN";
        break;
    }

    drv_debug_write_text("\r\n=== CALIBRATION RESULT - COPY TO actuator_calibration_config.h ===\r\n");

    (void)snprintf(message, sizeof(s_cal_define_message), "#define ACT_CAL_%s_VALID 1U\r\n", prefix);
    drv_debug_write_text(message);

    (void)snprintf(message, sizeof(s_cal_define_message), "#define ACT_CAL_%s_ZERO_RAW_REFERENCE %ldL\r\n", prefix,
                   (long)result->zero_raw);
    drv_debug_write_text(message);

    (void)snprintf(message, sizeof(s_cal_define_message), "#define ACT_CAL_%s_NINETY_RAW_REFERENCE %ldL\r\n", prefix,
                   (long)result->ninety_raw);
    drv_debug_write_text(message);

    (void)snprintf(message, sizeof(s_cal_define_message), "#define ACT_CAL_%s_STROKE_COUNTS %luUL\r\n", prefix,
                   (unsigned long)result->stroke_counts);
    drv_debug_write_text(message);

    (void)snprintf(message, sizeof(s_cal_define_message), "#define ACT_CAL_%s_DIRECTION_SIGN %ldL\r\n", prefix,
                   (long)result->direction_sign);
    drv_debug_write_text(message);

    drv_debug_write_text(
        "NOTE: ZERO/NINETY raw are current-session references. Re-home after power-up; stroke counts are reusable.\r\n"
        "===================================================================\r\n\r\n");
}

static void calibration_progress(const actuator_calibration_progress_t *progress, void *context)
{
    TRACE_ENTER(CT_F107);
    char *message = s_cal_progress_message;
    const actuator_profile_t *profile = (const actuator_profile_t *)context;

    if (progress == NULL)
    {
        return;
    }

    /* Calibration callbacks execute on MotorServiceTask. Track remaining stack
     * during G as well, not only between normal 400 Hz samples. */
    update_motor_stack_watermark();

    taskENTER_CRITICAL();

    g_status.calibration_status = (uint32_t)progress->status;

    g_status.calibration_iteration = progress->iteration;

    if (progress->event == ACTUATOR_CAL_EVENT_SAMPLE)
    {
        g_status.position_raw = progress->position_raw;
        g_status.velocity_actual_raw = progress->velocity_raw;
        g_status.torque_actual_raw = progress->torque_raw;
        g_status.position_sample_count++;
        update_angle_from_position(progress->position_raw);
    }
    else if (progress->event == ACTUATOR_CAL_EVENT_ZERO_FOUND)
    {
        g_status.calibration_zero_raw = progress->position_raw;
    }
    else if (progress->event == ACTUATOR_CAL_EVENT_NINETY_FOUND)
    {
        g_status.calibration_ninety_raw = progress->position_raw;
    }
    taskEXIT_CRITICAL();

    switch (progress->event)
    {
    case ACTUATOR_CAL_EVENT_START:
        drv_debug_write_text("CAL: START - low-speed hard-end calibration\r\n");
        break;

    case ACTUATOR_CAL_EVENT_HOMING_ZERO:
        drv_debug_write_text("CAL: HOMING CCW -> physical 0 deg\r\n");
        break;

    case ACTUATOR_CAL_EVENT_ZERO_FOUND:
        if (progress->iteration == 0U)
        {
            (void)snprintf(message, sizeof(s_cal_progress_message), "CAL: HOME 0deg found pos=%ld\r\n",
                           (long)progress->position_raw);
        }
        else
        {
            (void)snprintf(message, sizeof(s_cal_progress_message), "CAL: ITER %lu 0deg pos=%ld\r\n",
                           (unsigned long)progress->iteration, (long)progress->position_raw);
        }
        drv_debug_write_text(message);
        break;

    case ACTUATOR_CAL_EVENT_MOVE_TO_90:
        (void)snprintf(message, sizeof(s_cal_progress_message), "CAL: ITER %lu CW -> 90deg\r\n",
                       (unsigned long)progress->iteration);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_CAL_EVENT_NINETY_FOUND:
        (void)snprintf(message, sizeof(s_cal_progress_message), "CAL: ITER %lu 90deg pos=%ld\r\n",
                       (unsigned long)progress->iteration, (long)progress->position_raw);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_CAL_EVENT_MOVE_TO_ZERO:
        (void)snprintf(message, sizeof(s_cal_progress_message), "CAL: ITER %lu CCW -> 0deg\r\n",
                       (unsigned long)progress->iteration);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_CAL_EVENT_ANALYZE:
        drv_debug_write_text("CAL: ANALYZING endpoint repeatability\r\n");
        break;

    case ACTUATOR_CAL_EVENT_COMPLETE:
        (void)snprintf(message, sizeof(s_cal_progress_message),
                       "CAL: COMPLETE - actuator is held at 0deg (TMC retries=%lu)\r\n",
                       (unsigned long)ActuatorCalibration_GetTmcRetryCount());
        drv_debug_write_text(message);
        if (profile != NULL)
        {
            print_calibration_defines(profile, &s_calibration_result);
        }
        break;

    case ACTUATOR_CAL_EVENT_ABORTED:
        drv_debug_write_text("CAL: ABORTED - motor returned to HOLD\r\n");
        break;

    case ACTUATOR_CAL_EVENT_ERROR:
    {
        actuator_calibration_leg_diagnostic_t leg;
        ActuatorCalibration_GetLastLegDiagnostic(&leg);
        (void)snprintf(message, sizeof(s_cal_progress_message),
                       "CAL LEG: iter=%lu start=%ld last=%ld travel=%lu cmd=%ld actual=%ld torque=%ld\r\n",
                       (unsigned long)leg.iteration, (long)leg.start_raw, (long)leg.last_raw,
                       (unsigned long)leg.travel_counts, (long)leg.requested_velocity_raw,
                       (long)leg.actual_velocity_raw, (long)leg.torque_raw);
        drv_debug_write_text(message);
        if (progress->status == ACTUATOR_CAL_STATUS_NO_TRAVEL)
        {
            drv_debug_write_text(
                "CAL: NO TRAVEL on measured leg; check physical motion/feedback. Calibration invalid.\r\n");
        }
        (void)snprintf(message, sizeof(s_cal_progress_message),
                       "CAL: ERROR status=%u lastTmc=%u retries=%lu - motor returned to HOLD\r\n",
                       (unsigned int)progress->status, (unsigned int)ActuatorCalibration_GetLastTmcError(),
                       (unsigned long)ActuatorCalibration_GetTmcRetryCount());
        drv_debug_write_text(message);
        break;
    }
    case ACTUATOR_CAL_EVENT_SAMPLE:
    default:
        break;
    }
}
#endif

#if ACTUATOR_NSR_SOFT_STALL
static int32_t get_soft_creep_velocity_for_profile(actuator_type_t type)
{
    TRACE_ENTER(CT_F110);
    switch (type)
    {
    case ACTUATOR_TYPE_10KG:
        return (int32_t)ACTUATOR_SOFT_STALL_10KG_CREEP_VELOCITY_RAW;
    case ACTUATOR_TYPE_20KG:
        return (int32_t)ACTUATOR_SOFT_STALL_20KG_CREEP_VELOCITY_RAW;
    case ACTUATOR_TYPE_35KG:
        return (int32_t)ACTUATOR_SOFT_STALL_35KG_CREEP_VELOCITY_RAW;
    default:
        return 0;
    }
}

void svc_motor_control_print_soft_stall_config(void)
{
    TRACE_ENTER(CT_F111);
    char message[420];
    const actuator_profile_t *profile;
    int32_t creep_velocity;

    profile = ActuatorProfile_Get(g_status.actuator_type);
    creep_velocity = (profile != NULL) ? get_soft_creep_velocity_for_profile(profile->type) : 0;

    (void)snprintf(message, sizeof(message),
                   "SOFT CFG: sample=%luHz creepStart=%lu.%02lu%% contactArm=%lu.%02lu%% "
                   "cruise=%lu%% creep=%ld raw boostStep=%ld boostMax=%ld "
                   "contact=%lums overshoot=%lu.%02lu%%\r\n",
                   (unsigned long)ACTUATOR_SOFT_STALL_SAMPLE_RATE_HZ,
                   (unsigned long)(ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 / 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 % 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 / 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 % 100U),
                   (unsigned long)ACTUATOR_SOFT_STALL_CRUISE_VELOCITY_PERCENT, (long)creep_velocity,
                   (long)ACTUATOR_SOFT_STALL_CREEP_BOOST_STEP_RAW, (long)ACTUATOR_SOFT_STALL_CREEP_BOOST_MAX_RAW,
                   (unsigned long)ACTUATOR_SOFT_STALL_CONTACT_CONFIRM_MS,
                   (unsigned long)(ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100 / 100U),
                   (unsigned long)(ACTUATOR_SOFT_STALL_MAX_OVERSHOOT_PERCENT_X100 % 100U));
    drv_debug_write_text(message);

    if (s_actuator_reference.calibration_available != 0U)
    {
        (void)snprintf(message, sizeof(message),
                       "SOFT CAL: STORED VALID stroke=%lu dirSign=%ld anchor=%u "
                       "session0=%ld session90=%ld | X/Y enabled immediately. "
                       "If anchor=0 the first X/Y performs soft reference search.\r\n",
                       (unsigned long)s_actuator_reference.stroke_counts, (long)s_actuator_reference.direction_sign,
                       (unsigned int)s_actuator_reference.runtime_anchor_valid,
                       (long)s_actuator_reference.runtime_zero_raw, (long)s_actuator_reference.runtime_ninety_raw);
    }
    else
    {
        (void)snprintf(message, sizeof(message),
                       "SOFT CAL: NO STORED PARAMETERS. Run G once, copy printed "
                       "ACT_CAL_x_* macros into actuator_calibration_config.h and rebuild.\r\n");
    }
    drv_debug_write_text(message);
}

static void soft_stall_progress(const actuator_soft_stall_progress_t *progress, void *context)
{
    TRACE_ENTER(CT_F112);
    char *message = s_soft_progress_message;
    const char *dir_name;
    const actuator_profile_t *profile = (const actuator_profile_t *)context;

    if (progress == NULL)
    {
        return;
    }

    dir_name = (progress->direction == ACTUATOR_SOFT_STALL_DIRECTION_CW) ? "CW" : "CCW";

    taskENTER_CRITICAL();

    g_status.soft_stall_status = (uint32_t)progress->status;

    g_status.soft_stall_stage = (uint32_t)progress->stage;

    g_status.soft_stall_direction = (int32_t)progress->direction;

    g_status.soft_stall_creep_start_raw = progress->creep_start_raw;

    g_status.soft_stall_target_raw = progress->target_end_raw;

    g_status.soft_stall_distance_to_end = progress->distance_to_end_counts;

    g_status.soft_stall_retry_count = ActuatorSoftStall_GetTmcRetryCount();
    g_status.commanded_velocity_raw = progress->commanded_velocity_raw;

    if ((progress->event == ACTUATOR_SOFT_STALL_EVENT_CONTACT) ||
        (progress->event == ACTUATOR_SOFT_STALL_EVENT_REFERENCE_ESTABLISHED) ||
        (progress->event == ACTUATOR_SOFT_STALL_EVENT_COMPLETE))
    {

        g_status.soft_stall_contact_confirmed = 1U;
    }

    if (progress->stage == ACTUATOR_SOFT_STALL_STAGE_HOLD)
    {
        g_status.commanded_velocity_raw = 0;
    }

    if (progress->event == ACTUATOR_SOFT_STALL_EVENT_SAMPLE)
    {
        g_status.position_raw = progress->position_raw;
        g_status.velocity_actual_raw = progress->velocity_raw;
        g_status.torque_actual_raw = progress->torque_raw;
        g_status.position_sample_count++;
        update_angle_from_position(progress->position_raw);
    }
    taskEXIT_CRITICAL();

    switch (progress->event)
    {
    case ACTUATOR_SOFT_STALL_EVENT_START:
        (void)snprintf(message, sizeof(s_soft_progress_message), "SOFT: START %s pos=%ld creepAt=%ld target=%ld\r\n",
                       dir_name, (long)progress->position_raw, (long)progress->creep_start_raw,
                       (long)progress->target_end_raw);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_REFERENCE_SEARCH:
        (void)snprintf(message, sizeof(s_soft_progress_message),
                       "SOFT: %s FIRST-BOOT REFERENCE SEARCH vel=%ld - no G required\r\n", dir_name,
                       (long)progress->commanded_velocity_raw);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_REFERENCE_ESTABLISHED:
        (void)snprintf(message, sizeof(s_soft_progress_message),
                       "SOFT: %s REFERENCE ESTABLISHED at pos=%ld -> HOLD\r\n", dir_name, (long)progress->position_raw);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_CRUISE:
        (void)snprintf(message, sizeof(s_soft_progress_message), "SOFT: %s CRUISE -> creep at %lu.%02lu%% stroke\r\n",
                       dir_name, (unsigned long)(ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 / 100U),
                       (unsigned long)(ACTUATOR_SOFT_STALL_CREEP_START_PERCENT_X100 % 100U));
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_CREEP:
        (void)snprintf(message, sizeof(s_soft_progress_message),
                       "SOFT: %s CREEP pos=%ld target=%ld vel=%ld; contact arms at %lu.%02lu%%\r\n", dir_name,
                       (long)progress->position_raw, (long)progress->target_end_raw,
                       (long)progress->commanded_velocity_raw,
                       (unsigned long)(ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 / 100U),
                       (unsigned long)(ACTUATOR_SOFT_STALL_CONTACT_ARM_PERCENT_X100 % 100U));
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_CREEP_BOOST:
        (void)snprintf(message, sizeof(s_soft_progress_message),
                       "SOFT: %s PRE-END LOAD STALL -> creep boost to %ld raw\r\n", dir_name,
                       (long)progress->commanded_velocity_raw);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_CONTACT:
        (void)snprintf(message, sizeof(s_soft_progress_message),
                       "SOFT: %s CONTACT pos=%ld dEnd=%ld posStable=%u velLow=%u -> HOLD\r\n", dir_name,
                       (long)progress->position_raw, (long)progress->distance_to_end_counts,
                       (unsigned int)progress->position_stable, (unsigned int)progress->velocity_low);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_COMPLETE:
        (void)snprintf(
            message, sizeof(s_soft_progress_message), "SOFT: %s COMPLETE final=%ld ref=%u retries=%lu boosts=%lu\r\n",
            dir_name, (long)s_soft_stall_result.final_position_raw,
            (unsigned int)s_actuator_reference.runtime_anchor_valid,
            (unsigned long)ActuatorSoftStall_GetTmcRetryCount(), (unsigned long)s_soft_stall_result.creep_boost_count);
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_ABORTED:
        drv_debug_write_text("SOFT: ABORTED -> HOLD\r\n");
        break;

    case ACTUATOR_SOFT_STALL_EVENT_ERROR:
        (void)snprintf(message, sizeof(s_soft_progress_message),
                       "SOFT: ERROR status=%u lastTmc=%u retries=%lu -> HOLD\r\n", (unsigned int)progress->status,
                       (unsigned int)ActuatorSoftStall_GetLastTmcError(),
                       (unsigned long)ActuatorSoftStall_GetTmcRetryCount());
        drv_debug_write_text(message);
        break;

    case ACTUATOR_SOFT_STALL_EVENT_SAMPLE:
    default:
        (void)profile;
        break;
    }
}
#endif

static void process_motor_command(const motor_command_t *command)
{
    TRACE_ENTER(CT_F113);
    const actuator_profile_t *profile;
    tmc6460_status_t status;

#if ACTUATOR_NSR_AUTO_CALIBRATION
    actuator_calibration_status_t cal_status;
#endif

#if ACTUATOR_NSR_SOFT_STALL
    actuator_soft_stall_status_t soft_status;

    actuator_soft_stall_direction_t soft_direction;
#endif
    uint32_t chip_id = 0U;

    if (command == NULL)
    {
        return;
    }

    switch (command->type)
    {
    case MOTOR_COMMAND_SELECT_PROFILE:
        profile = ActuatorProfile_Get(command->actuator_type);
        if (profile == NULL)
        {
            set_command_result(TMC6460_INVALID_PARAM, MOTOR_STATE_ERROR, 0);
            break;
        }

        if (s_motor.initialized != 0U)
        {
            (void)TMC6460_MotorStopHold(&s_motor);
        }

        status = TMC6460_MotorConfigure(&s_motor, &profile->motor, TMC_EXPECTED_CHIP_ID, &chip_id);

#if ACTUATOR_NSR_AUTO_CALIBRATION
        memset(&s_calibration_result, 0, sizeof(s_calibration_result));
#endif

#if ACTUATOR_NSR_SOFT_STALL
        memset(&s_soft_stall_result, 0, sizeof(s_soft_stall_result));
#endif
        ActuatorReference_Clear(&s_actuator_reference);
        if (status == TMC6460_OK)
        {
            (void)ActuatorReference_LoadCompileTime(command->actuator_type, &s_actuator_reference);
        }

#if ACTUATOR_NSR_SOFT_STALL
        s_soft_stall_abort_requested = 0U;
#endif

        taskENTER_CRITICAL();
        g_status.tmc_chip_id = chip_id;
        g_status.tmc_status = status;
        g_status.actuator_type = command->actuator_type;
        g_status.actuator_initialized = (status == TMC6460_OK) ? 1U : 0U;
        g_status.motor_state = (status == TMC6460_OK) ? MOTOR_STATE_HOLD : MOTOR_STATE_ERROR;
        g_status.commanded_velocity_raw = 0;

#if ACTUATOR_NSR_AUTO_CALIBRATION
        g_status.calibration_active = 0U;
#endif
        g_status.calibration_valid = s_actuator_reference.calibration_available;

#if ACTUATOR_NSR_AUTO_CALIBRATION
        g_status.calibration_status = (s_actuator_reference.calibration_available != 0U)
                                          ? ACTUATOR_CAL_STATUS_OK
                                          : ACTUATOR_CAL_STATUS_NOT_INITIALIZED;

        g_status.calibration_iteration = 0U;
#endif
        g_status.calibration_zero_raw = 0;
        g_status.calibration_ninety_raw = 0;
        g_status.calibration_stroke_signed_counts =
            (s_actuator_reference.calibration_available != 0U)
                ? (s_actuator_reference.direction_sign * (int32_t)s_actuator_reference.stroke_counts)
                : 0;
        g_status.calibration_stroke_counts = s_actuator_reference.stroke_counts;
        g_status.calibration_params_loaded = s_actuator_reference.calibration_available;
        g_status.position_reference_valid = 0U;
        g_status.reference_zero_raw = 0;
        g_status.reference_ninety_raw = 0;

#if ACTUATOR_NSR_AUTO_CALIBRATION
        g_status.calibration_zero_spread_counts = 0U;

        g_status.calibration_ninety_spread_counts = 0U;
#endif
        g_status.angle_deg_x100 = 0;

#if ACTUATOR_NSR_SOFT_STALL
        g_status.soft_stall_active = 0U;

        g_status.soft_stall_contact_confirmed = 0U;

        g_status.soft_stall_status = (s_actuator_reference.calibration_available != 0U)
                                         ? ACTUATOR_SOFT_STALL_STATUS_OK
                                         : ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;

        g_status.soft_stall_stage = ACTUATOR_SOFT_STALL_STAGE_IDLE;
#endif
        g_status.motor_stack_min_free_words = 0xFFFFFFFFUL;
        g_status.motor_stack_margin_low = 0U;

#if ACTUATOR_NSR_SOFT_STALL
        g_status.soft_stall_direction = 0;

        g_status.soft_stall_creep_start_raw = 0;

        g_status.soft_stall_target_raw = 0;

        g_status.soft_stall_distance_to_end = 0;

        g_status.soft_stall_final_raw = 0;

        g_status.soft_stall_retry_count = 0U;

        g_status.soft_stall_creep_boost_count = 0U;

        g_status.soft_stall_reference_search_used = 0U;
#endif
        g_status.command_count++;
        if (status != TMC6460_OK)
        {
            g_status.command_error_count++;
        }
        taskEXIT_CRITICAL();

        /* Even when configuration fails, read a snapshot so the debug
             * terminal shows Hall state / driver state / status flags. */
        (void)refresh_tmc_feedback();

        if ((status == TMC6460_OK) && (s_actuator_reference.calibration_available != 0U))
        {
            char cal_message[180];
            (void)snprintf(cal_message, sizeof(cal_message),
                           "STORED CAL LOADED: stroke=%lu dir=%ld."
#if ACTUATOR_NSR_SOFT_STALL
                           " X/Y enabled; first X/Y after reset will soft-reference the requested end."
#endif
                           "\r\n",
                           (unsigned long)s_actuator_reference.stroke_counts,
                           (long)s_actuator_reference.direction_sign);
            drv_debug_write_text(cal_message);
        }
        else if (status == TMC6460_OK)
        {
            drv_debug_write_text(
#if ACTUATOR_NSR_AUTO_CALIBRATION
                "NO STORED CAL: G is required once; paste printed ACT_CAL_x_* defines and rebuild.\r\n"
#else
                "NO STORED CAL: supply validated ACT_CAL_x_* values and rebuild.\r\n"
#endif
            );
        }
        break;

    case MOTOR_COMMAND_RUN_CW:
        status = TMC6460_MotorRunCW(&s_motor);
        set_command_result(status, MOTOR_STATE_CW, (status == TMC6460_OK) ? s_motor.commanded_velocity_raw : 0);
        (void)refresh_tmc_feedback();
        break;

    case MOTOR_COMMAND_RUN_CCW:
        status = TMC6460_MotorRunCCW(&s_motor);
        set_command_result(status, MOTOR_STATE_CCW, (status == TMC6460_OK) ? s_motor.commanded_velocity_raw : 0);
        (void)refresh_tmc_feedback();
        break;

    case MOTOR_COMMAND_STOP_HOLD:
        status = TMC6460_MotorStopHold(&s_motor);
        set_command_result(status, MOTOR_STATE_HOLD, 0);
        (void)refresh_tmc_feedback();
        break;

    case MOTOR_COMMAND_REFRESH_DIAGNOSTICS:
    {
        char report[224];
        status = refresh_tmc_feedback();
        taskENTER_CRITICAL();
        g_status.command_count++;
        if (status != TMC6460_OK)
        {
            g_status.command_error_count++;
        }
        taskEXIT_CRITICAL();
        (void)snprintf(report, sizeof(report),
                       "DIAG profile=%u state=%u tmc=%u pos=%ld vel=%ld cmd=%ld chip=0x%08lX errors=%lu\r\n",
                       (unsigned int)g_status.actuator_type, (unsigned int)g_status.motor_state, (unsigned int)status,
                       (long)g_status.position_raw, (long)g_status.velocity_actual_raw,
                       (long)g_status.commanded_velocity_raw, (unsigned long)g_status.chip_status_flags,
                       (unsigned long)g_status.command_error_count);
        drv_debug_write_text(report);
        break;
    }

#if ACTUATOR_NSR_AUTO_CALIBRATION
    case MOTOR_COMMAND_AUTO_CALIBRATE:
        profile = ActuatorProfile_Get(command->actuator_type);
        if ((profile == NULL) || (s_motor.initialized == 0U))
        {
            taskENTER_CRITICAL();

            g_status.calibration_status = ACTUATOR_CAL_STATUS_NOT_INITIALIZED;
            g_status.command_error_count++;
            g_status.command_count++;
            taskEXIT_CRITICAL();
            break;
        }

        s_calibration_abort_requested = 0U;

#if ACTUATOR_NSR_SOFT_STALL
        s_soft_stall_abort_requested = 0U;
#endif

        memset(&s_calibration_result, 0, sizeof(s_calibration_result));
        ActuatorReference_Clear(&s_actuator_reference);
        taskENTER_CRITICAL();
        update_reference_status();
        taskEXIT_CRITICAL();

        drv_debug_write_text("CAL: COMMAND STARTED - running full G calibration\r\n");
        update_motor_stack_watermark();

        taskENTER_CRITICAL();

        g_status.calibration_active = 1U;
        g_status.calibration_valid = 0U;

        g_status.calibration_status = ACTUATOR_CAL_STATUS_OK;

        g_status.calibration_iteration = 0U;
        g_status.motor_state = MOTOR_STATE_CALIBRATING;
        g_status.commanded_velocity_raw = 0;
        g_status.command_count++;
        taskEXIT_CRITICAL();

        cal_status = ActuatorCalibration_Run(&s_motor, profile, &s_calibration_abort_requested, &s_calibration_result,
                                             calibration_progress, (void *)profile);

        if (cal_status != ACTUATOR_CAL_STATUS_OK)
        {
            (void)refresh_tmc_feedback();
            (void)snprintf(s_cal_progress_message, sizeof(s_cal_progress_message),
                           "CAL POST-HOLD: target=%ld actual=%ld drv=0x%08lX motion=0x%08lX events=0x%08lX\r\n",
                           (long)g_status.velocity_target_readback_raw, (long)g_status.velocity_actual_raw,
                           (unsigned long)g_status.gate_driver_config, (unsigned long)g_status.motor_motion_config,
                           (unsigned long)g_status.chip_events);
            drv_debug_write_text(s_cal_progress_message);
        }

        if ((cal_status == ACTUATOR_CAL_STATUS_OK) && (s_calibration_result.valid != 0U))
        {
            ActuatorReference_UpdateFromCalibration(&s_actuator_reference, &s_calibration_result);
        }

        taskENTER_CRITICAL();

        g_status.calibration_active = 0U;

        g_status.calibration_status = (uint32_t)cal_status;
        g_status.calibration_valid = s_calibration_result.valid;
        g_status.calibration_zero_raw = s_calibration_result.zero_raw;
        g_status.calibration_ninety_raw = s_calibration_result.ninety_raw;
        g_status.calibration_stroke_signed_counts = s_calibration_result.stroke_signed_counts;
        g_status.calibration_stroke_counts = s_calibration_result.stroke_counts;

        g_status.calibration_zero_spread_counts = s_calibration_result.zero_spread_counts;

        g_status.calibration_ninety_spread_counts = s_calibration_result.ninety_spread_counts;
        update_reference_status();

#if ACTUATOR_NSR_SOFT_STALL
        g_status.soft_stall_status = (s_actuator_reference.calibration_available != 0U)
                                         ? ACTUATOR_SOFT_STALL_STATUS_OK
                                         : ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;
#endif

        if (cal_status == ACTUATOR_CAL_STATUS_OK)
        {
            g_status.motor_state = MOTOR_STATE_HOLD;
            g_status.commanded_velocity_raw = 0;
        }
        else if (cal_status == ACTUATOR_CAL_STATUS_ABORTED)
        {
            g_status.motor_state = MOTOR_STATE_HOLD;
            g_status.commanded_velocity_raw = 0;
        }
        else
        {
            g_status.motor_state = MOTOR_STATE_ERROR;
            g_status.command_error_count++;
            if (cal_status == ACTUATOR_CAL_STATUS_TMC_ERROR)
            {
                g_status.tmc_status = TMC6460_ERROR;
            }
        }
        taskEXIT_CRITICAL();

        (void)refresh_tmc_feedback();
        break;

#endif
#if ACTUATOR_NSR_SOFT_STALL
    case MOTOR_COMMAND_SOFT_CW:
    case MOTOR_COMMAND_SOFT_CCW:
        profile = ActuatorProfile_Get(command->actuator_type);
        if ((profile == NULL) || (s_motor.initialized == 0U))
        {
            taskENTER_CRITICAL();

            g_status.soft_stall_status = ACTUATOR_SOFT_STALL_STATUS_NOT_INITIALIZED;
            g_status.command_count++;
            g_status.command_error_count++;
            taskEXIT_CRITICAL();
            break;
        }

        if (s_actuator_reference.calibration_available == 0U)
        {
            taskENTER_CRITICAL();

            g_status.soft_stall_status = ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;
            g_status.command_count++;
            g_status.command_error_count++;
            taskEXIT_CRITICAL();
            drv_debug_write_text("ERR: NO STORED CALIBRATION. "
#if ACTUATOR_NSR_AUTO_CALIBRATION
                                 "RUN G ONCE, "
#endif
                                 "COPY ACT_CAL_x_* MACROS, REBUILD\r\n");
            break;
        }

        soft_direction = (command->type == MOTOR_COMMAND_SOFT_CW) ? ACTUATOR_SOFT_STALL_DIRECTION_CW
                                                                  : ACTUATOR_SOFT_STALL_DIRECTION_CCW;

        s_soft_stall_abort_requested = 0U;

        memset(&s_soft_stall_result, 0, sizeof(s_soft_stall_result));

        taskENTER_CRITICAL();

        g_status.soft_stall_active = 1U;

        g_status.soft_stall_contact_confirmed = 0U;

        g_status.soft_stall_status = ACTUATOR_SOFT_STALL_STATUS_OK;

        g_status.soft_stall_stage = ACTUATOR_SOFT_STALL_STAGE_IDLE;

        g_status.soft_stall_direction = (int32_t)soft_direction;
        g_status.motor_state =
            (soft_direction == ACTUATOR_SOFT_STALL_DIRECTION_CW) ? MOTOR_STATE_SOFT_CW : MOTOR_STATE_SOFT_CCW;
        g_status.command_count++;
        taskEXIT_CRITICAL();

        soft_status = ActuatorSoftStall_Run(&s_motor, profile, &s_actuator_reference, soft_direction,
                                            &s_soft_stall_abort_requested, &s_soft_stall_result, soft_stall_progress,
                                            (void *)profile);

        taskENTER_CRITICAL();

        g_status.soft_stall_active = 0U;

        g_status.soft_stall_status = (uint32_t)soft_status;

        g_status.soft_stall_stage = ACTUATOR_SOFT_STALL_STAGE_HOLD;

        g_status.soft_stall_contact_confirmed = s_soft_stall_result.contact_confirmed;

        g_status.soft_stall_final_raw = s_soft_stall_result.final_position_raw;

        g_status.soft_stall_retry_count = s_soft_stall_result.tmc_retry_count;

        g_status.soft_stall_creep_boost_count = s_soft_stall_result.creep_boost_count;

        g_status.soft_stall_reference_search_used = s_soft_stall_result.reference_search_used;
        update_reference_status();
        g_status.commanded_velocity_raw = 0;
        g_status.motor_state = MOTOR_STATE_HOLD;

        if ((soft_status != ACTUATOR_SOFT_STALL_STATUS_OK) && (soft_status != ACTUATOR_SOFT_STALL_STATUS_ABORTED))
        {
            g_status.command_error_count++;
        }

        if (soft_status == ACTUATOR_SOFT_STALL_STATUS_TMC_ERROR)
        {
            g_status.tmc_status = ActuatorSoftStall_GetLastTmcError();
        }
        taskEXIT_CRITICAL();

        (void)refresh_tmc_feedback();
        break;

#endif
    default:
        set_command_result(TMC6460_INVALID_PARAM, MOTOR_STATE_ERROR, 0);
        break;
    }
}

#else
static void process_motor_command(const motor_command_t *command)
{
    TRACE_ENTER(CT_F116);
    ActuatorSR_Command(command->type, command->actuator_type);
}
#endif

BaseType_t svc_motor_control_queue_command(motor_command_type_t type, actuator_type_t actuator_type)
{
    TRACE_ENTER(CT_F117);
    motor_command_t command;
    /* State eligibility is checked by the motor owner when dequeued. */

    command.type = type;
    command.actuator_type = actuator_type;

    BaseType_t sent = xQueueSend(s_motor_command_queue, &command, pdMS_TO_TICKS(20U));
    TRACE_VALUE(sent == pdPASS ? CT_Q_PUT : CT_Q_FULL, (int32_t)type);
    return sent;
}

int32_t svc_motor_control_init(void)
{
    TRACE_ENTER(CT_F118);
    memset((void *)&g_status, 0, sizeof(g_status));

#if ACTUATOR_NSR_AUTO_CALIBRATION
    memset(&s_calibration_result, 0, sizeof(s_calibration_result));
#endif

#if ACTUATOR_NSR_SOFT_STALL
    memset(&s_soft_stall_result, 0, sizeof(s_soft_stall_result));
#endif
#if ACTUATOR_TYPE == ACTUATOR_TYPE_NSR
    ActuatorReference_Clear(&s_actuator_reference);
#endif

    g_status.tmc_status = TMC6460_ERROR;
    g_status.actuator_type = ACTUATOR_TYPE_10KG;
    g_status.motor_state = MOTOR_STATE_NOT_INITIALIZED;

#if ACTUATOR_NSR_AUTO_CALIBRATION
    g_status.calibration_status = ACTUATOR_CAL_STATUS_NOT_INITIALIZED;
#endif

#if ACTUATOR_NSR_SOFT_STALL
    g_status.soft_stall_status = ACTUATOR_SOFT_STALL_STATUS_CALIBRATION_REQUIRED;

    g_status.soft_stall_stage = ACTUATOR_SOFT_STALL_STAGE_IDLE;
#endif

    /* SPI-only device context; generated SPI2 configuration is already initialized. */
    TMC6460_Init(&s_tmc_device, TMC_COMM_TIMEOUT_MS);

    TMC6460_MotorInitContext(&s_motor, &s_tmc_device);

    s_motor_command_queue = xQueueCreate(MOTOR_COMMAND_QUEUE_LENGTH, sizeof(motor_command_t));
    if (s_motor_command_queue == NULL)
    {
        return -1;
    }

#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
    ActuatorSR_Init(&s_motor);
#endif
    return 0;
}

/* FreeRTOS stack-overflow hook. In debug builds this is preferable to silent
 * stack corruption followed by an unrelated HardFault. Inspect the globals in
 * IAR Watch if execution stops here. */
void motor_stack_overflow_hook(TaskHandle_t xTask, char *pcTaskName)
{
    (void)pcTaskName;
    g_stack_overflow_detected = 1U;
    g_stack_overflow_task = xTask;
    taskDISABLE_INTERRUPTS();
    for (;;)
    {
        /* Breakpoint here during development. */
    }
}

uint32_t motor_command_queue_spaces(void)
{
    TRACE_ENTER(CT_F119);
    if (s_motor_command_queue == NULL)
    {
        return 0U;
    }
    return (uint32_t)uxQueueSpacesAvailable(s_motor_command_queue);
}

#if ACTUATOR_NSR_AUTO_CALIBRATION || ACTUATOR_NSR_SOFT_STALL || ACTUATOR_TYPE == ACTUATOR_TYPE_SR
void svc_motor_control_request_abort(void)
{
    TRACE_ENTER(CT_F120);
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
    ActuatorSR_RequestStop();
    if (s_motor_command_queue != NULL)
    {
        (void)xQueueReset(s_motor_command_queue);
        TRACE_EVENT(CT_Q_RESET);
    }
#endif
#if ACTUATOR_NSR_AUTO_CALIBRATION
    if (g_status.calibration_active)
    {
        s_calibration_abort_requested = 1U;
    }
#endif
#if ACTUATOR_NSR_SOFT_STALL
    if (g_status.soft_stall_active)
    {
        s_soft_stall_abort_requested = 1U;
    }
#endif
}
#endif
BaseType_t svc_motor_control_process_next(TickType_t wait)
{
    TRACE_ENTER(CT_F121);
    motor_command_t command;
    if (s_motor_command_queue == NULL)
    {
        return pdFALSE;
    }
    if (xQueueReceive(s_motor_command_queue, &command, wait) != pdPASS)
    {
        return pdFALSE;
    }
    TRACE_VALUE(CT_Q_GET, (int32_t)command.type);
    process_motor_command(&command);
    return pdTRUE;
}
BaseType_t svc_motor_control_sample(void)
{
    TRACE_ENTER(CT_F122);
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
    ActuatorSR_Poll();
    return pdTRUE;
#else
    static uint32_t feedback_divider;
    tmc6460_status_t status;
    int32_t position_raw;
    if (!s_motor.initialized)
    {
        return pdFALSE;
    }
    update_motor_stack_watermark();

    position_raw = 0;
    status = TMC6460_MotorReadPosition(&s_motor, &position_raw);

    taskENTER_CRITICAL();
    g_status.tmc_status = status;
    if (status == TMC6460_OK)
    {
        TRACE_VALUE(CT_POS, position_raw);
        g_status.position_raw = position_raw;
        g_status.position_sample_count++;
        update_angle_from_position(position_raw);
    }
    else
    {
        g_status.position_error_count++;
    }
    taskEXIT_CRITICAL();

    if (status == TMC6460_OK)
    {
        feedback_divider++;
        if (feedback_divider >= FEEDBACK_REFRESH_POSITION_SAMPLES)
        {
            feedback_divider = 0U;
            (void)refresh_tmc_feedback();
        }
    }

    return pdTRUE;
#endif
}
