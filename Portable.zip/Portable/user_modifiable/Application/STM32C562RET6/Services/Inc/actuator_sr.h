#ifndef ACTUATOR_SR_H
#define ACTUATOR_SR_H
#include "svc_motor_control.h"
#include "tmc6460_motor.h"
#include <stdbool.h>
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
typedef enum
{
    SR_BOOT,
    SR_CAL_CW,
    SR_CAL_CCW,
    SR_READY,
    SR_RUN_CW,
    SR_RUN_CCW,
    SR_FAULT,
    SR_MANUAL_CW,
    SR_MANUAL_CCW,
    SR_REFERENCE_CW
} actuator_sr_state_t;
typedef enum
{
    SR_ERROR_NONE,
    SR_ERROR_CONFIG,
    SR_ERROR_TMC,
    SR_ERROR_STOP,
    SR_ERROR_ABORTED_CALIBRATION,
    SR_ERROR_NO_TRAVEL,
    SR_ERROR_DIRECTION,
    SR_ERROR_TIMEOUT,
    SR_ERROR_OVERSHOOT
} actuator_sr_error_t;
void ActuatorSR_Init(tmc6460_motor_t *motor);
void ActuatorSR_Poll(void);
void ActuatorSR_Command(motor_command_type_t command, actuator_type_t profile);
void ActuatorSR_RequestStop(void);
void ActuatorSR_PrintStatus(void);
bool ActuatorSR_IsReady(void);
#endif
#endif
