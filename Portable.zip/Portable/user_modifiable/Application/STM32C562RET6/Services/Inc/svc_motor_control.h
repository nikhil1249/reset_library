#ifndef SVC_MOTOR_CONTROL_H
#define SVC_MOTOR_CONTROL_H

#include "app_config.h"
#include "actuator_profile.h"
#include "tmc6460.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdint.h>

typedef enum
{
    MOTOR_STATE_NOT_INITIALIZED = 0,
    MOTOR_STATE_HOLD = 1,
    MOTOR_STATE_CW = 2,
    MOTOR_STATE_CCW = 3,
    MOTOR_STATE_ERROR = 4,
#if ACTUATOR_NSR_AUTO_CALIBRATION
    MOTOR_STATE_CALIBRATING = 5,
#endif
#if ACTUATOR_NSR_SOFT_STALL
    MOTOR_STATE_SOFT_CW = 6,
    MOTOR_STATE_SOFT_CCW = 7,
#endif
} motor_state_t;

typedef struct
{
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
    uint32_t sr_state;
    uint32_t sr_error;
#endif
    uint32_t tmc_chip_id;
    tmc6460_status_t tmc_status;
    actuator_type_t actuator_type;
    uint8_t actuator_initialized;
    motor_state_t motor_state;

    int32_t commanded_velocity_raw;
    int32_t velocity_target_readback_raw;
    int32_t velocity_actual_raw;
    int32_t position_raw;
    int32_t torque_actual_raw;
    int32_t flux_actual_raw;

    uint32_t chip_inputs_raw;
    uint32_t hall_raw;
    uint32_t hall_logic;
    uint32_t hall_count;
    uint32_t hall_events;
    uint32_t feedback_ch_b_raw;
    uint32_t phi_e_raw;
    uint32_t chip_status_flags;
    uint32_t chip_events;
    uint32_t gate_driver_config;
    uint32_t motor_motion_config;
    uint32_t feedback_output_config;

    /* Auto-calibration status. calibration_status uses
     * actuator_calibration_status_t numeric values to keep this public status
     * structure decoupled from the calibration module header. */
#if ACTUATOR_NSR_AUTO_CALIBRATION
    uint8_t calibration_active;
#endif
    uint8_t calibration_valid;
#if ACTUATOR_NSR_AUTO_CALIBRATION
    uint32_t calibration_status;
    uint32_t calibration_iteration;
#endif
    int32_t calibration_zero_raw;
    int32_t calibration_ninety_raw;
    int32_t calibration_stroke_signed_counts;
    uint32_t calibration_stroke_counts;
#if ACTUATOR_NSR_AUTO_CALIBRATION
    uint32_t calibration_zero_spread_counts;
    uint32_t calibration_ninety_spread_counts;
#endif
    int32_t angle_deg_x100;

    /* Persistent calibration availability and current-session raw anchor. */
    uint8_t calibration_params_loaded;
    uint8_t position_reference_valid;
    int32_t reference_zero_raw;
    int32_t reference_ninety_raw;

    /* Software soft-stall / soft-end-stop status. */
#if ACTUATOR_NSR_SOFT_STALL
    uint8_t soft_stall_active;
    uint8_t soft_stall_contact_confirmed;
    uint32_t soft_stall_status;
    uint32_t soft_stall_stage;
    int32_t soft_stall_direction;
    int32_t soft_stall_creep_start_raw;
    int32_t soft_stall_target_raw;
    int32_t soft_stall_distance_to_end;
    int32_t soft_stall_final_raw;
    uint32_t soft_stall_retry_count;
    uint32_t soft_stall_creep_boost_count;
    uint8_t soft_stall_reference_search_used;

#endif
    uint32_t position_sample_count;
    uint32_t position_error_count;
    uint32_t diagnostic_error_count;
    uint32_t command_count;
    uint32_t command_error_count;

    /* Runtime stack diagnostics. Value is in StackType_t words, not bytes. */
    uint32_t motor_stack_min_free_words;
    uint8_t motor_stack_margin_low;
} actuator_status_t;

extern volatile actuator_status_t g_status;

/* Set by FreeRTOS if a task stack overflow is detected. Useful in IAR Watch. */
extern volatile uint32_t g_stack_overflow_detected;
extern volatile TaskHandle_t g_stack_overflow_task;

typedef enum
{
    MOTOR_COMMAND_SELECT_PROFILE = 0,
    MOTOR_COMMAND_RUN_CW = 1,
    MOTOR_COMMAND_RUN_CCW = 2,
    MOTOR_COMMAND_STOP_HOLD = 3,
    MOTOR_COMMAND_REFRESH_DIAGNOSTICS = 4,
#if ACTUATOR_NSR_AUTO_CALIBRATION || ACTUATOR_TYPE == ACTUATOR_TYPE_SR
    MOTOR_COMMAND_AUTO_CALIBRATE = 5,
#endif
#if ACTUATOR_NSR_SOFT_STALL || ACTUATOR_TYPE == ACTUATOR_TYPE_SR
    MOTOR_COMMAND_SOFT_CW = 6,
    MOTOR_COMMAND_SOFT_CCW = 7,
#endif
} motor_command_type_t;

BaseType_t svc_motor_control_queue_command(motor_command_type_t type, actuator_type_t actuator_type);
int32_t svc_motor_control_init(void);
BaseType_t svc_motor_control_process_next(TickType_t wait);
BaseType_t svc_motor_control_sample(void);
TickType_t svc_motor_control_sample_period(uint32_t *phase);
#if ACTUATOR_NSR_AUTO_CALIBRATION || ACTUATOR_NSR_SOFT_STALL || ACTUATOR_TYPE == ACTUATOR_TYPE_SR
void svc_motor_control_request_abort(void);
#endif
#if ACTUATOR_NSR_SOFT_STALL
void svc_motor_control_print_soft_stall_config(void);
#endif
void motor_stack_overflow_hook(TaskHandle_t task, char *name);
uint32_t motor_command_queue_spaces(void);
#if MOTION_DEBUG_INTERVAL_MS != 0
void svc_motor_control_debug_output(void);
#endif

#endif /* SVC_MOTOR_CONTROL_H */
