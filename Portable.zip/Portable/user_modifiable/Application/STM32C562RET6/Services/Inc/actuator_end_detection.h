#include "call_trace.h"
#ifndef ACTUATOR_END_DETECTION_H
#define ACTUATOR_END_DETECTION_H
#include <stdbool.h>
#include <stdint.h>

/* Shared NSR/SR consecutive-sample confirmation. A rejected vote resets
 * its sequence; position-only fallback is counted independently. */
static inline void ActuatorEnd_Count(uint32_t *contact, uint32_t *position, bool position_stable, bool contact_vote)
{
    TRACE_ENTER(CT_F177);
    *contact = contact_vote ? *contact + 1U : 0U;
    *position = position_stable ? *position + 1U : 0U;
}
#endif
