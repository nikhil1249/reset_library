#ifndef ACTUATOR_PROFILE_H
#define ACTUATOR_PROFILE_H

#include "tmc6460_motor.h"
#include <stdint.h>

/* Raw torque/flux limits. The 15 kg pair is defined for integration, but
 * no selectable 15 kg profile exists until its remaining settings are supplied. */
#define ACTUATOR_10KG_RUN_TORQUE_RAW 900
#define ACTUATOR_10KG_HOLD_TORQUE_RAW 1200
#define ACTUATOR_15KG_RUN_TORQUE_RAW 2000
#define ACTUATOR_15KG_HOLD_TORQUE_RAW 2000
#define ACTUATOR_20KG_RUN_TORQUE_RAW 1500
#define ACTUATOR_20KG_HOLD_TORQUE_RAW 1500
#define ACTUATOR_35KG_RUN_TORQUE_RAW 2500
#define ACTUATOR_35KG_HOLD_TORQUE_RAW 2500
#define ACTUATOR_10KG_MAX_TORQUE_RAW 1200
#define ACTUATOR_10KG_DEFAULT_VELOCITY_RAW 9000000
#define ACTUATOR_10KG_MAX_VELOCITY_RAW 9000000
#define ACTUATOR_20KG_MAX_TORQUE_RAW 2000
#define ACTUATOR_20KG_DEFAULT_VELOCITY_RAW 1000000
#define ACTUATOR_20KG_MAX_VELOCITY_RAW 1500000
#define ACTUATOR_35KG_MAX_TORQUE_RAW 2500
#define ACTUATOR_35KG_DEFAULT_VELOCITY_RAW 1000000
#define ACTUATOR_35KG_MAX_VELOCITY_RAW 1500000

typedef enum
{
    ACTUATOR_TYPE_10KG = 0,
    ACTUATOR_TYPE_20KG,
    ACTUATOR_TYPE_35KG,
    ACTUATOR_TYPE_COUNT
} actuator_type_t;

typedef struct
{
    actuator_type_t type;
    char command_key;
    const char *name;
    tmc6460_motor_profile_t motor;
} actuator_profile_t;

const actuator_profile_t *ActuatorProfile_Get(actuator_type_t type);
const actuator_profile_t *ActuatorProfile_FromCommand(char command);

#endif /* ACTUATOR_PROFILE_H */
