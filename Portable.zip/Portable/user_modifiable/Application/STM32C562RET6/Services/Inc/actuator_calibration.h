#include "app_config.h"
#if ACTUATOR_NSR_AUTO_CALIBRATION
#ifndef ACTUATOR_CALIBRATION_H
#define ACTUATOR_CALIBRATION_H

#include "actuator_calibration_config.h"
#include "actuator_profile.h"
#include "tmc6460_motor.h"

#include <stdint.h>

typedef enum
{
    ACTUATOR_CAL_STATUS_OK = 0,
    ACTUATOR_CAL_STATUS_INVALID_PARAM,
    ACTUATOR_CAL_STATUS_NOT_INITIALIZED,
    ACTUATOR_CAL_STATUS_TMC_ERROR,
    ACTUATOR_CAL_STATUS_TIMEOUT,
    ACTUATOR_CAL_STATUS_UNSTABLE,
    ACTUATOR_CAL_STATUS_ABORTED,
    ACTUATOR_CAL_STATUS_NO_TRAVEL /* A measured leg never left its previous endpoint. */
} actuator_calibration_status_t;

typedef struct
{
    int32_t start_raw, last_raw, requested_velocity_raw, actual_velocity_raw, torque_raw;
    uint32_t travel_counts, iteration;
} actuator_calibration_leg_diagnostic_t;
void ActuatorCalibration_GetLastLegDiagnostic(actuator_calibration_leg_diagnostic_t *out);

typedef enum
{
    ACTUATOR_CAL_EVENT_START = 0,
    ACTUATOR_CAL_EVENT_HOMING_ZERO,
    ACTUATOR_CAL_EVENT_SAMPLE,
    ACTUATOR_CAL_EVENT_ZERO_FOUND,
    ACTUATOR_CAL_EVENT_MOVE_TO_90,
    ACTUATOR_CAL_EVENT_NINETY_FOUND,
    ACTUATOR_CAL_EVENT_MOVE_TO_ZERO,
    ACTUATOR_CAL_EVENT_ANALYZE,
    ACTUATOR_CAL_EVENT_COMPLETE,
    ACTUATOR_CAL_EVENT_ERROR,
    ACTUATOR_CAL_EVENT_ABORTED
} actuator_calibration_event_t;

typedef struct
{
    actuator_calibration_event_t event;
    uint32_t iteration;
    int32_t position_raw;
    int32_t velocity_raw;
    int32_t torque_raw;
    actuator_calibration_status_t status;
} actuator_calibration_progress_t;

typedef void (*actuator_calibration_progress_cb_t)(const actuator_calibration_progress_t *progress, void *context);

typedef struct
{
    actuator_type_t actuator_type;

    int32_t zero_samples[ACTUATOR_CALIBRATION_ITERATION_COUNT];
    int32_t ninety_samples[ACTUATOR_CALIBRATION_ITERATION_COUNT];

    int32_t zero_average_raw;
    int32_t ninety_average_raw;
    int32_t zero_raw;
    int32_t ninety_raw;

    int32_t stroke_signed_counts;
    uint32_t stroke_counts;
    int32_t direction_sign;

    uint32_t zero_spread_counts;
    uint32_t ninety_spread_counts;
    uint32_t stroke_min_counts;
    uint32_t stroke_max_counts;
    uint32_t stroke_average_counts;

    uint8_t valid;
} actuator_calibration_result_t;

actuator_calibration_status_t ActuatorCalibration_Run(tmc6460_motor_t *motor, const actuator_profile_t *profile,
                                                      volatile uint8_t *abort_requested,
                                                      actuator_calibration_result_t *result,
                                                      actuator_calibration_progress_cb_t progress_cb,
                                                      void *progress_context);

/* Diagnostics for the most recent calibration run.  retry_count counts each
 * failed low-level TMC operation that was automatically retried. */
tmc6460_status_t ActuatorCalibration_GetLastTmcError(void);
uint32_t ActuatorCalibration_GetTmcRetryCount(void);

#endif /* ACTUATOR_CALIBRATION_H */

#endif
