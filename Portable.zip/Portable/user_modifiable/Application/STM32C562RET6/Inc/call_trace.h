#ifndef CALL_TRACE_H
#define CALL_TRACE_H
#include "app_config.h"

/* Removing the app_config definition disables all trace calls and storage. */
#ifndef TRACE_CALL_STACK
#define TRACE_CALL_STACK 0
#endif
#if TRACE_CALL_STACK != 0 && TRACE_CALL_STACK != 1
#error "TRACE_CALL_STACK must be 0 or 1"
#endif

#if TRACE_CALL_STACK
#include <stdint.h>
#include "call_trace_ids.h"
void CallTrace_Record(call_trace_id_t id, int32_t value);
void CallTrace_Command(uint8_t ch);
void CallTrace_Drain(void);
#define TRACE_ENTER(id) CallTrace_Record((id), 0)
#define TRACE_EVENT(id) CallTrace_Record((id), 0)
#define TRACE_VALUE(id, value) CallTrace_Record((id), (int32_t)(value))
#define TRACE_COMMAND(ch) CallTrace_Command((uint8_t)(ch))
#define TRACE_PUMP() CallTrace_Drain()
#define TRACE_RX_WAIT_MS 20U
#else
#define TRACE_ENTER(id) ((void)0)
#define TRACE_EVENT(id) ((void)0)
#define TRACE_VALUE(id, value) ((void)0)
#define TRACE_COMMAND(ch) ((void)0)
#define TRACE_PUMP() ((void)0)
#define TRACE_RX_WAIT_MS 1000U
#endif
#endif
