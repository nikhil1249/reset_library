#ifndef APP_CONFIG_H
#define APP_CONFIG_H
#define FIRMWARE_VERSION "2.0"
/* Raw feedback averages. Set the logging interval to 0 to compile out diagnostics. */
#ifndef MOTION_DEBUG_INTERVAL_MS
#define MOTION_DEBUG_INTERVAL_MS 2000U
#endif
#ifndef MOTION_DEBUG_SAMPLE_INTERVAL_MS
#define MOTION_DEBUG_SAMPLE_INTERVAL_MS 20U
#endif
#if MOTION_DEBUG_INTERVAL_MS != 0 &&                                                                                   \
    (MOTION_DEBUG_SAMPLE_INTERVAL_MS < 5U || MOTION_DEBUG_INTERVAL_MS < MOTION_DEBUG_SAMPLE_INTERVAL_MS ||             \
     MOTION_DEBUG_INTERVAL_MS > 60000U)
#error "Motion diagnostics require 5 <= sample interval <= log interval <= 60000 ms"
#endif
#define SR_STOP_ATTEMPTS 4U
#define SR_STOP_RETRY_MS 2U
#define ACTUATOR_FULL_TRAVEL_DEG_X100 9000L
#define PERCENT_X100_SCALE 10000L
#define PERCENT_SCALE 100L
#define MILLISECONDS_PER_SECOND 1000U

/* Override in the project preprocessor settings for feature-matrix builds. */
#ifndef ENABLE_AUTO_CALIBRATION
#define ENABLE_AUTO_CALIBRATION 1
#endif
#ifndef ENABLE_SOFT_STALL
#define ENABLE_SOFT_STALL 1
#endif
#if (ENABLE_AUTO_CALIBRATION != 0 && ENABLE_AUTO_CALIBRATION != 1) || (ENABLE_SOFT_STALL != 0 && ENABLE_SOFT_STALL != 1)
#error "Feature switches must be 0 or 1"
#endif
/* Family selection is independent of the A/B/C load profile. */
#define ACTUATOR_TYPE_NSR 0U
#define ACTUATOR_TYPE_SR 1U
#ifndef ACTUATOR_TYPE
#define ACTUATOR_TYPE ACTUATOR_TYPE_SR
#endif
#define STALL_MODE_HARD 0U
#define STALL_MODE_SOFT 1U
#ifndef STALL_MODE
#define STALL_MODE STALL_MODE_SOFT
#endif
#if ACTUATOR_TYPE != ACTUATOR_TYPE_NSR && ACTUATOR_TYPE != ACTUATOR_TYPE_SR
#error "Invalid ACTUATOR_TYPE"
#endif
#if STALL_MODE != STALL_MODE_HARD && STALL_MODE != STALL_MODE_SOFT
#error "Invalid STALL_MODE"
#endif
#define ACTUATOR_NSR_AUTO_CALIBRATION (ACTUATOR_TYPE == ACTUATOR_TYPE_NSR && ENABLE_AUTO_CALIBRATION)
#define ACTUATOR_NSR_SOFT_STALL (ACTUATOR_TYPE == ACTUATOR_TYPE_NSR && ENABLE_SOFT_STALL)
/* Initial diagnostic profile only; A/B/C must initialize a profile before motion. */
#ifndef SR_STARTUP_PROFILE
#define SR_STARTUP_PROFILE ACTUATOR_TYPE_20KG
#endif
/* SR-only velocity magnitude and minimum private profile velocity limit. */
#ifndef SR_RUN_VELOCITY_RAW
#define SR_RUN_VELOCITY_RAW 3000000L
#endif
/* Zero selects the selected profile's existing running torque limit.
 * Set a positive raw value to override each direction independently. */
#ifndef SR_CW_TORQUE_LIMIT_RAW
#define SR_CW_TORQUE_LIMIT_RAW 0L
#endif
#ifndef SR_CCW_TORQUE_LIMIT_RAW
#define SR_CCW_TORQUE_LIMIT_RAW 0L
#endif
#define SR_SAMPLE_RATE_HZ 200U
#define SR_MIN_TRAVEL_COUNTS 1000L
#define SR_SOFT_MAX_MOVE_TIME_MS 30000U
#if SR_RUN_VELOCITY_RAW <= 0 || SR_RUN_VELOCITY_RAW > 2147483647L
#error "SR velocity must be a positive int32 magnitude"
#endif
#if SR_CW_TORQUE_LIMIT_RAW < 0 || SR_CW_TORQUE_LIMIT_RAW > 65535 || SR_CCW_TORQUE_LIMIT_RAW < 0 ||                     \
    SR_CCW_TORQUE_LIMIT_RAW > 65535
#error "SR torque must be 0 (profile default) or 1..65535"
#endif
/* Application policy only. Peripheral configuration belongs to CubeMX2. */
#define DEBUG_RX_STREAM_SIZE 128U
#define DEBUG_UART_ENABLE 1U
#define DEBUG_UART_TIMEOUT_MS 50U
#define MOTOR_COMMAND_QUEUE_LENGTH 12U
#define SPI_INTERFACE_DMA_ENABLE 1U
#define TASK_NAME_DEBUG "DebugCommand"
#define TASK_PRIO_DEBUG 3U
#define TASK_STACK_DEBUG 384U
#define TASK_NAME_TMC6460 "MotorService"
#define TASK_PRIO_TMC6460_DRIVER 4U
#define TASK_STACK_TMC6460_DRIVER 2048U
#define TASK_TMC6460_STACK_WARN_WORDS 256U
#define TMC_COMM_TIMEOUT_MS 25U
#define TMC_EXPECTED_CHIP_ID 0x36343630UL
#define TMC_INTERFACE_NAME "SPI2"
#define TMC_POSITION_SAMPLE_RATE_HZ 400U
#define TMC_SPI_ENABLE 1U
#define TMC_STARTUP_DELAY_MS 100U
/* Debug UART is USART2 only; TMC6460 transport is always SPI2 DMA. */
#if DEBUG_UART_ENABLE != 1U || TMC_SPI_ENABLE != 1U || SPI_INTERFACE_DMA_ENABLE != 1U
#error "This target requires USART2 debug IRQ and SPI2 motor DMA"
#endif
#if TASK_STACK_TMC6460_DRIVER < 2048U
#error "Use the migrated 2048-word calibration stack, not the baseline 320-word polling stack"
#endif
#endif
