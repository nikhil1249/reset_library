#ifndef CALL_TRACE_IDS_H
#define CALL_TRACE_IDS_H
/* Fnnn labels map to TRACE_FUNCTION_MAP.md. */
typedef enum
{
    CT_S_M_WAIT,
    CT_S_M_OK,
    CT_S_M_NO,
    CT_S_M_REL,
    CT_S_M_BAD,
    CT_S_D_WAIT,
    CT_S_D_OK,
    CT_S_D_TO,
    CT_S_D_GIVE,
    CT_S_D_BAD,
    CT_S_D_CLR,
    CT_S_TX_START,
    CT_S_TX_DONE,
    CT_S_ERR,
    CT_U_M_WAIT,
    CT_U_M_OK,
    CT_U_M_NO,
    CT_U_M_REL,
    CT_U_M_BAD,
    CT_U_D_WAIT,
    CT_U_D_OK,
    CT_U_D_TO,
    CT_U_D_GIVE,
    CT_U_D_BAD,
    CT_U_D_CLR,
    CT_U_TX_START,
    CT_U_TX_DONE,
    CT_U_RX,
    CT_U_RX_PUT,
    CT_U_RX_DROP,
    CT_U_RX_GET,
    CT_Q_PUT,
    CT_Q_FULL,
    CT_Q_GET,
    CT_Q_RESET,
    CT_POS,
    CT_SR_STATE,
    CT_CMD_A,
    CT_CMD_B,
    CT_CMD_C,
    CT_CMD_D,
    CT_CMD_E,
    CT_CMD_F,
    CT_CMD_G,
    CT_CMD_H,
    CT_CMD_I,
    CT_CMD_J,
    CT_CMD_K,
    CT_CMD_L,
    CT_CMD_M,
    CT_CMD_N,
    CT_CMD_O,
    CT_CMD_P,
    CT_CMD_Q,
    CT_CMD_R,
    CT_CMD_S,
    CT_CMD_T,
    CT_CMD_U,
    CT_CMD_V,
    CT_CMD_W,
    CT_CMD_X,
    CT_CMD_Y,
    CT_CMD_Z,
    CT_F001,
    CT_F002,
    CT_F003,
    CT_F004,
    CT_F005,
    CT_F006,
    CT_F007,
    CT_F009,
    CT_F010,
    CT_F011,
    CT_F012,
    CT_F013,
    CT_F014,
    CT_F015,
    CT_F016,
    CT_F017,
    CT_F018,
    CT_F019,
    CT_F020,
    CT_F021,
    CT_F022,
    CT_F023,
    CT_F024,
    CT_F025,
    CT_F026,
    CT_F027,
    CT_F028,
    CT_F029,
    CT_F030,
    CT_F031,
    CT_F032,
    CT_F033,
    CT_F034,
    CT_F035,
    CT_F036,
    CT_F037,
    CT_F038,
    CT_F039,
    CT_F040,
    CT_F041,
    CT_F042,
    CT_F043,
    CT_F044,
    CT_F046,
    CT_F047,
    CT_F048,
    CT_F049,
    CT_F050,
    CT_F051,
    CT_F052,
    CT_F053,
    CT_F054,
    CT_F055,
    CT_F056,
    CT_F057,
    CT_F058,
    CT_F059,
    CT_F060,
    CT_F061,
    CT_F062,
    CT_F063,
    CT_F064,
    CT_F065,
    CT_F066,
    CT_F067,
    CT_F068,
    CT_F069,
    CT_F070,
    CT_F071,
    CT_F072,
    CT_F073,
    CT_F074,
    CT_F075,
    CT_F076,
    CT_F077,
    CT_F079,
    CT_F080,
    CT_F081,
    CT_F082,
    CT_F083,
    CT_F084,
    CT_F085,
    CT_F086,
    CT_F087,
    CT_F088,
    CT_F089,
    CT_F090,
    CT_F091,
    CT_F092,
    CT_F093,
    CT_F094,
    CT_F095,
    CT_F096,
    CT_F097,
    CT_F098,
    CT_F099,
    CT_F100,
    CT_F101,
    CT_F102,
    CT_F103,
    CT_F104,
    CT_F105,
    CT_F106,
    CT_F107,
    CT_F110,
    CT_F111,
    CT_F112,
    CT_F113,
    CT_F116,
    CT_F117,
    CT_F118,
    CT_F119,
    CT_F120,
    CT_F121,
    CT_F122,
    CT_F123,
    CT_F124,
    CT_F125,
    CT_F126,
    CT_F127,
    CT_F128,
    CT_F129,
    CT_F130,
    CT_F131,
    CT_F144,
    CT_F145,
    CT_F146,
    CT_F147,
    CT_F148,
    CT_F149,
    CT_F150,
    CT_F151,
    CT_F152,
    CT_F153,
    CT_F154,
    CT_F155,
    CT_F157,
    CT_F158,
    CT_F159,
    CT_F160,
    CT_F161,
    CT_F162,
    CT_F163,
    CT_F164,
    CT_F165,
    CT_F166,
    CT_F167,
    CT_F168,
    CT_F169,
    CT_F170,
    CT_F171,
    CT_F172,
    CT_F173,
    CT_F174,
    CT_F175,
    CT_F176,
    CT_F177,
    CT_F178,
    CT_F179,
    CT_F180,
    CT_F181,
    CT_F182,
    CT_COUNT
} call_trace_id_t;
#define CALL_TRACE_DESCRIPTORS                                                                                         \
    {                                                                                                                  \
        {"S mx wait", 1U},                                                                                             \
        {"S mx take", 1U},                                                                                             \
        {"S mx busy", 1U},                                                                                             \
        {"S mx rel", 1U},                                                                                              \
        {"S mx rel err", 1U},                                                                                          \
        {"S sem wait", 1U},                                                                                            \
        {"S sem take", 1U},                                                                                            \
        {"S sem to", 1U},                                                                                              \
        {"S sem give", 1U},                                                                                            \
        {"S sem full", 1U},                                                                                            \
        {"S sem clr", 1U},                                                                                             \
        {"S dma start", 1U},                                                                                           \
        {"S txrx done", 1U},                                                                                           \
        {"S err", 1U},                                                                                                 \
        {"U mx wait", 3U},                                                                                             \
        {"U mx take", 3U},                                                                                             \
        {"U mx busy", 3U},                                                                                             \
        {"U mx rel", 3U},                                                                                              \
        {"U mx rel err", 3U},                                                                                          \
        {"U sem wait", 3U},                                                                                            \
        {"U sem take", 3U},                                                                                            \
        {"U sem to", 3U},                                                                                              \
        {"U sem give", 3U},                                                                                            \
        {"U sem full", 3U},                                                                                            \
        {"U sem clr", 3U},                                                                                             \
        {"U tx start", 3U},                                                                                            \
        {"U tx done", 3U},                                                                                             \
        {"U rx", 3U},                                                                                                  \
        {"U str put", 3U},                                                                                             \
        {"U str full", 3U},                                                                                            \
        {"U str get", 3U},                                                                                             \
        {"Q put", 4U},                                                                                                 \
        {"Q full", 4U},                                                                                                \
        {"Q get", 4U},                                                                                                 \
        {"Q clr", 0U},                                                                                                 \
        {"pos", 5U},                                                                                                   \
        {"SR state", 4U},                                                                                              \
        {"A cmd rx", 0U},                                                                                              \
        {"B cmd rx", 0U},                                                                                              \
        {"C cmd rx", 0U},                                                                                              \
        {"D cmd rx", 0U},                                                                                              \
        {"E cmd rx", 0U},                                                                                              \
        {"F cmd rx", 0U},                                                                                              \
        {"G cmd rx", 0U},                                                                                              \
        {"H cmd rx", 0U},                                                                                              \
        {"I cmd rx", 0U},                                                                                              \
        {"J cmd rx", 0U},                                                                                              \
        {"K cmd rx", 0U},                                                                                              \
        {"L cmd rx", 0U},                                                                                              \
        {"M cmd rx", 0U},                                                                                              \
        {"N cmd rx", 0U},                                                                                              \
        {"O cmd rx", 0U},                                                                                              \
        {"P cmd rx", 0U},                                                                                              \
        {"Q cmd rx", 0U},                                                                                              \
        {"R cmd rx", 0U},                                                                                              \
        {"S cmd rx", 0U},                                                                                              \
        {"T cmd rx", 0U},                                                                                              \
        {"U cmd rx", 0U},                                                                                              \
        {"V cmd rx", 0U},                                                                                              \
        {"W cmd rx", 0U},                                                                                              \
        {"X cmd rx", 0U},                                                                                              \
        {"Y cmd rx", 0U},                                                                                              \
        {"Z cmd rx", 0U},                                                                                              \
        {"F001 tmc6460_select", 1U},                                                                                   \
        {"F002 tmc6460_deselect", 1U},                                                                                 \
        {"F003 S.get_context", 1U},                                                                                    \
        {"F004 S.find_by_handle", 1U},                                                                                 \
        {"F005 S.clear_semaphore", 1U},                                                                                \
        {"F006 S.init", 0U},                                                                                           \
        {"F007 S.transfer", 1U},                                                                                       \
        {"F009 S.get_stats", 1U},                                                                                      \
        {"F010 S.on_complete", 1U},                                                                                    \
        {"F011 S.on_error", 1U},                                                                                       \
        {"F012 U.FindByHandle", 3U},                                                                                   \
        {"F013 U.ClearSemaphore", 3U},                                                                                 \
        {"F014 U.Register", 2U},                                                                                       \
        {"F015 U.Init", 2U},                                                                                           \
        {"F016 U.Lock", 3U},                                                                                           \
        {"F017 U.Unlock", 3U},                                                                                         \
        {"F018 U.WaitCompletion", 3U},                                                                                 \
        {"F019 U.Write", 3U},                                                                                          \
        {"F020 U.ArmBufferedRx", 3U},                                                                                  \
        {"F021 U.StartBufferedRx", 2U},                                                                                \
        {"F022 U.ReadBuffered", 3U},                                                                                   \
        {"F023 U.GetStats", 3U},                                                                                       \
        {"F024 U.on_tx_complete", 3U},                                                                                 \
        {"F025 U.on_rx_complete", 3U},                                                                                 \
        {"F026 U.on_error", 3U},                                                                                       \
        {"F027 U.write_text", 3U},                                                                                     \
        {"F028 C.GetLastLegDiagnostic", 1U},                                                                           \
        {"F029 C.RecordTmcFailure", 1U},                                                                               \
        {"F030 C.Abs32", 1U},                                                                                          \
        {"F031 C.AbsDiff32", 1U},                                                                                      \
        {"F032 C.GetVelocity", 1U},                                                                                    \
        {"F033 C.GetTorqueThreshold", 1U},                                                                             \
        {"F034 C.ReadMotionSampleRetry", 1U},                                                                          \
        {"F035 C.ReadPositionRetry", 1U},                                                                              \
        {"F036 C.SetVelocityRetry", 1U},                                                                               \
        {"F037 C.StopHoldRetry", 1U},                                                                                  \
        {"F038 C.Notify", 1U},                                                                                         \
        {"F039 C.Median", 1U},                                                                                         \
        {"F040 C.Average", 1U},                                                                                        \
        {"F041 C.Spread", 1U},                                                                                         \
        {"F042 C.CaptureEndpoint", 1U},                                                                                \
        {"F043 C.MoveToEnd", 1U},                                                                                      \
        {"F044 C.Analyze", 1U},                                                                                        \
        {"F046 C.Run", 0U},                                                                                            \
        {"F047 C.GetLastTmcError", 1U},                                                                                \
        {"F048 C.GetTmcRetryCount", 1U},                                                                               \
        {"F049 P.Get", 1U},                                                                                            \
        {"F050 P.FromCommand", 1U},                                                                                    \
        {"F051 R.SaturateInt64", 1U},                                                                                  \
        {"F052 R.Clear", 1U},                                                                                          \
        {"F053 R.LoadCompileTime", 1U},                                                                                \
        {"F054 R.UpdateFromCalibration", 1U},                                                                          \
        {"F055 R.AnchorAtEnd", 1U},                                                                                    \
        {"F056 R.PositionToDegX100", 1U},                                                                              \
        {"F057 SS.Abs32", 1U},                                                                                         \
        {"F058 SS.AbsDiff32", 1U},                                                                                     \
        {"F059 SS.Clamp32", 1U},                                                                                       \
        {"F060 SS.SaturateInt64", 1U},                                                                                 \
        {"F061 SS.Reached", 1U},                                                                                       \
        {"F062 SS.DistanceToEnd", 1U},                                                                                 \
        {"F063 SS.MsToSamples", 1U},                                                                                   \
        {"F064 SS.GetFixedCreepVelocity", 1U},                                                                         \
        {"F065 SS.GetReferenceSearchVel", 1U},                                                                         \
        {"F066 SS.GetTorqueThreshold", 1U},                                                                            \
        {"F067 SS.RecordTmcFailure", 1U},                                                                              \
        {"F068 SS.ReadMotionRetry", 1U},                                                                               \
        {"F069 SS.ReadPositionRetry", 1U},                                                                             \
        {"F070 SS.SetVelocityRetry", 1U},                                                                              \
        {"F071 SS.StopHoldRetry", 1U},                                                                                 \
        {"F072 SS.Notify", 1U},                                                                                        \
        {"F073 SS.ComputeBoundaryX100", 1U},                                                                           \
        {"F074 SS.ComputeCreepVelocity", 1U},                                                                          \
        {"F075 SS.RunReferenceSearch", 1U},                                                                            \
        {"F076 SS.RunAnchored", 1U},                                                                                   \
        {"F077 SS.Run", 0U},                                                                                           \
        {"F079 SS.GetTmcRetryCount", 1U},                                                                              \
        {"F080 SS.GetLastTmcError", 1U},                                                                               \
        {"F081 SR.calibrating", 1U},                                                                                   \
        {"F082 SR.moving_cw", 1U},                                                                                     \
        {"F083 SR.moving", 1U},                                                                                        \
        {"F084 SR.set_state", 1U},                                                                                     \
        {"F085 actuator_zero_end_reache", 1U},                                                                         \
        {"F086 actuator_90_contact_arme", 1U},                                                                         \
        {"F087 actuator_90_end_reached", 1U},                                                                          \
        {"F088 SR.update_position", 1U},                                                                               \
        {"F089 SR.stop", 0U},                                                                                          \
        {"F090 SR.read_position", 1U},                                                                                 \
        {"F091 SR.begin", 0U},                                                                                         \
        {"F092 SR.Init", 0U},                                                                                          \
        {"F093 SR.IsReady", 1U},                                                                                       \
        {"F094 SR.RequestStop", 0U},                                                                                   \
        {"F095 SR.PrintStatus", 1U},                                                                                   \
        {"F096 SR.clear_calibration", 0U},                                                                             \
        {"F097 SR.select_profile", 0U},                                                                                \
        {"F098 SR.Command", 0U},                                                                                       \
        {"F099 SR.Poll", 1U},                                                                                          \
        {"F100 SV.sample_period", 1U},                                                                                 \
        {"F101 update_motor_stack_water", 1U},                                                                         \
        {"F102 update_angle_from_positi", 1U},                                                                         \
        {"F103 update_reference_status", 1U},                                                                          \
        {"F104 set_command_result", 1U},                                                                               \
        {"F105 refresh_tmc_feedback", 1U},                                                                             \
        {"F106 print_calibration_define", 1U},                                                                         \
        {"F107 calibration_progress", 1U},                                                                             \
        {"F110 get_soft_creep_velocity_", 1U},                                                                         \
        {"F111 SV.print_soft_stall_conf", 1U},                                                                         \
        {"F112 soft_stall_progress", 1U},                                                                              \
        {"F113 process_motor_command", 0U},                                                                            \
        {"F116 process_motor_command", 0U},                                                                            \
        {"F117 SV.queue_command", 0U},                                                                                 \
        {"F118 SV.init", 0U},                                                                                          \
        {"F119 motor_command_queue_spac", 1U},                                                                         \
        {"F120 SV.request_abort", 0U},                                                                                 \
        {"F121 SV.process_next", 1U},                                                                                  \
        {"F122 SV.sample", 1U},                                                                                        \
        {"F123 app_main_error_trap", 1U},                                                                              \
        {"F124 app_main", 0U},                                                                                         \
        {"F125 RAM.StackFree", 1U},                                                                                    \
        {"F126 RAM.Get", 1U},                                                                                          \
        {"F127 RAM.FormatDetailed", 1U},                                                                               \
        {"F128 TD.get_handle", 1U},                                                                                    \
        {"F129 TD.get_state", 1U},                                                                                     \
        {"F130 debug_print_help", 1U},                                                                                 \
        {"F131 TD.run", 0U},                                                                                           \
        {"F144 TM.get_handle", 1U},                                                                                    \
        {"F145 TM.get_state", 1U},                                                                                     \
        {"F146 TM.run", 0U},                                                                                           \
        {"F147 T.ConvertTransportStatus", 1U},                                                                         \
        {"F148 T.Init", 1U},                                                                                           \
        {"F149 T.ReadRegister", 1U},                                                                                   \
        {"F150 T.WriteRegister", 1U},                                                                                  \
        {"F151 T.ReadField", 1U},                                                                                      \
        {"F152 T.WriteField", 1U},                                                                                     \
        {"F153 T.ReadChipID", 1U},                                                                                     \
        {"F154 T.CheckCommunication", 1U},                                                                             \
        {"F155 M.PackLimit", 1U},                                                                                      \
        {"F157 M.Abs32", 1U},                                                                                          \
        {"F158 M.WriteConfig", 1U},                                                                                    \
        {"F159 M.VerifyDriverOn", 1U},                                                                                 \
        {"F160 M.EnsureDriverEnabled", 1U},                                                                            \
        {"F161 M.VerifyRunState", 1U},                                                                                 \
        {"F162 M.InitContext", 1U},                                                                                    \
        {"F163 M.Configure", 0U},                                                                                      \
        {"F164 M.SetVelocity", 0U},                                                                                    \
        {"F165 M.RunCW", 0U},                                                                                          \
        {"F166 M.RunCCW", 0U},                                                                                         \
        {"F167 M.StopHold", 0U},                                                                                       \
        {"F168 M.ReadPosition", 1U},                                                                                   \
        {"F169 M.ReadMotionSample", 1U},                                                                               \
        {"F170 M.ReadFeedback", 1U},                                                                                   \
        {"F171 T.FromSpiStatus", 1U},                                                                                  \
        {"F172 T.SPI_BuildFrame", 1U},                                                                                 \
        {"F173 T.SPI_ResponseAddress", 1U},                                                                            \
        {"F174 T.SPI_ResponseData", 1U},                                                                               \
        {"F175 T.ReadRegister", 1U},                                                                                   \
        {"F176 T.WriteRegister", 1U},                                                                                  \
        {"F177 ActuatorEnd_Count", 1U},                                                                                \
        {"F178 HAL_UART_TxCpltCallback", 3U},                                                                          \
        {"F179 HAL_UART_RxCpltCallback", 3U},                                                                          \
        {"F180 HAL_UART_ErrorCallback", 3U},                                                                           \
        {"F181 HAL_SPI_TxRxCpltCallback", 1U},                                                                         \
        {"F182 HAL_SPI_ErrorCallback", 1U},                                                                            \
    }
#endif
