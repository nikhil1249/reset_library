#include "call_trace.h"
#include "runtime_memory.h"
#include "app_config.h"
#include "svc_motor_control.h"
#include "task_tmc6460.h"
#include "task_debug.h"
#include "drv_tmc6460.h"
#include "drv_uart.h"

#include "FreeRTOS.h"
#include "task.h"

#include <stdio.h>
#include <string.h>

static uint32_t RuntimeMemory_StackFree(TaskHandle_t handle)
{
    TRACE_ENTER(CT_F125);
    if (handle == NULL)
    {
        return 0U;
    }
    return (uint32_t)uxTaskGetStackHighWaterMark(handle);
}

void RuntimeMemory_Get(runtime_memory_snapshot_t *s)
{
    TRACE_ENTER(CT_F126);
    spi_interface_stats_t spi_stats;
    drv_debug_stats_t uart_stats;
    uint32_t free_heap;
    uint32_t min_heap;

    if (s == NULL)
    {
        return;
    }
    memset(s, 0, sizeof(*s));

    free_heap = (uint32_t)xPortGetFreeHeapSize();
    min_heap = (uint32_t)xPortGetMinimumEverFreeHeapSize();

    s->heap_total_bytes = configTOTAL_HEAP_SIZE;
    s->heap_free_bytes = free_heap;
    s->heap_min_ever_free_bytes = min_heap;
    s->heap_used_now_bytes = (configTOTAL_HEAP_SIZE >= free_heap) ? (configTOTAL_HEAP_SIZE - free_heap) : 0U;
    s->heap_peak_used_bytes = (configTOTAL_HEAP_SIZE >= min_heap) ? (configTOTAL_HEAP_SIZE - min_heap) : 0U;

    s->motor_stack_free_words = RuntimeMemory_StackFree(task_tmc6460_get_handle());
    s->command_stack_free_words = RuntimeMemory_StackFree(task_debug_get_handle());

    s->motor_queue_spaces = motor_command_queue_spaces();
    s->motor_queue_length = MOTOR_COMMAND_QUEUE_LENGTH;

    spi_interface_get_stats(SPI_INTERFACE_PORT_TMC, &spi_stats);
    s->spi_transfers = spi_stats.transfers;
    s->spi_timeouts = spi_stats.timeouts;
    s->spi_errors = spi_stats.errors;

    DRV_DEBUG_GetStats(&uart_stats);
    s->uart_tx_transfers = uart_stats.tx_transfers;
    s->uart_rx_bytes = uart_stats.buffered_rx_bytes;
    s->uart_rx_dropped = uart_stats.buffered_rx_dropped;
    s->uart_errors = uart_stats.errors;
}

int RuntimeMemory_FormatDetailed(char *buffer, size_t size, const runtime_memory_snapshot_t *s)
{
    TRACE_ENTER(CT_F127);
    if ((buffer == NULL) || (size == 0U) || (s == NULL))
    {
        return 0;
    }
    return snprintf(buffer, size,
                    "MEMORY RTOS: heap total=%lu free=%lu minEverFree=%lu usedNow=%lu peakUsed=%lu\r\n"
                    "STACK free words: Motor=%lu Command=%lu (x4 bytes on Cortex-M33)\r\n"
                    "IPC: motorQueue free=%lu/%lu\r\n"
                    "I/O: SPI DMA xfers=%lu timeout=%lu err=%lu | UART IRQ tx=%lu rxBytes=%lu drop=%lu err=%lu\r\n",
                    (unsigned long)s->heap_total_bytes, (unsigned long)s->heap_free_bytes,
                    (unsigned long)s->heap_min_ever_free_bytes, (unsigned long)s->heap_used_now_bytes,
                    (unsigned long)s->heap_peak_used_bytes, (unsigned long)s->motor_stack_free_words,
                    (unsigned long)s->command_stack_free_words,

                    (unsigned long)s->motor_queue_spaces, (unsigned long)s->motor_queue_length,
                    (unsigned long)s->spi_transfers, (unsigned long)s->spi_timeouts, (unsigned long)s->spi_errors,
                    (unsigned long)s->uart_tx_transfers, (unsigned long)s->uart_rx_bytes,
                    (unsigned long)s->uart_rx_dropped, (unsigned long)s->uart_errors);
}
