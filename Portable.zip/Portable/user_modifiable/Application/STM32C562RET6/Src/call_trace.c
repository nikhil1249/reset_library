#include "call_trace.h"
#if TRACE_CALL_STACK
#include "drv_uart.h"
#include "stm32_hal.h"
#include <stddef.h>

/* Producers never format, allocate, wait, take RTOS locks or call UART.
 * This recorder may run inside SPI/UART interrupts or nested critical sections.
 * Only DebugCommand drains it, outside peripheral/RTOS critical sections. */
#define TRACE_CAPACITY 128U
#define TRACE_PERIOD_MS 5000U
#define TRACE_TX_TIMEOUT_MS 10U
#define TRACE_PERIODIC 1U
#define TRACE_UART 2U
#define TRACE_HAS_VALUE 4U
typedef struct
{
    const char *label;
    uint8_t flags;
} trace_description_t;
typedef struct
{
    uint32_t ms;
    int32_t value;
    uint16_t id;
} trace_record_t;
static const trace_description_t descriptions[CT_COUNT] = CALL_TRACE_DESCRIPTORS;
static trace_record_t records[TRACE_CAPACITY];
static uint32_t last_ms[CT_COUNT];
static uint32_t seen[(CT_COUNT + 31U) / 32U];
static uint32_t head, tail, dropped, last_drop_ms;
static volatile uint8_t uart_output;
static char line[64];
_Static_assert((TRACE_CAPACITY & (TRACE_CAPACITY - 1U)) == 0U, "Trace capacity must be a power of two");
_Static_assert(CT_COUNT < 65536, "Trace id overflow");
_Static_assert(CT_CMD_Z - CT_CMD_A == 25, "Command ids must be contiguous");

void CallTrace_Record(call_trace_id_t id, int32_t value)
{
    uint32_t key, now, flags, bit, word, exception;
    trace_record_t *entry;
    if ((uint32_t)id >= (uint32_t)CT_COUNT)
    {
        return;
    }
    /* NMI/fault/system exception logging is intentionally unsupported. */
    exception = __get_IPSR();
    if (exception != 0U && exception < 16U)
    {
        return;
    }
    flags = descriptions[id].flags;
    if ((flags & TRACE_UART) != 0U && uart_output != 0U)
    {
        return;
    }
    key = __get_PRIMASK();
    __disable_irq();
    now = HAL_GetTick();
    word = (uint32_t)id / 32U;
    bit = 1UL << ((uint32_t)id % 32U);
    if ((flags & TRACE_PERIODIC) != 0U && (seen[word] & bit) != 0U && (uint32_t)(now - last_ms[id]) < TRACE_PERIOD_MS)
    {
        __set_PRIMASK(key);
        return;
    }
    if ((uint32_t)(head - tail) >= TRACE_CAPACITY)
    {
        if (dropped != UINT32_MAX)
        {
            ++dropped;
        }
        __set_PRIMASK(key);
        return;
    }
    last_ms[id] = now;
    seen[word] |= bit;
    entry = &records[head & (TRACE_CAPACITY - 1U)];
    entry->ms = now;
    entry->id = (uint16_t)id;
    entry->value = value;
    ++head;
    __set_PRIMASK(key);
}

void CallTrace_Command(uint8_t ch)
{
    if (ch >= (uint8_t)'A' && ch <= (uint8_t)'Z')
    {
        CallTrace_Record((call_trace_id_t)(CT_CMD_A + ch - (uint8_t)'A'), 0);
    }
}

/* Bounded formatting, no printf family and no per-call large stack buffer. */
static size_t append_char(size_t at, char ch)
{
    if (at < sizeof(line) - 1U)
    {
        line[at++] = ch;
    }
    return at;
}
static size_t append_text(size_t at, const char *text)
{
    while (*text != '\0' && at < sizeof(line) - 1U)
    {
        line[at++] = *text++;
    }
    return at;
}
static size_t append_unsigned(size_t at, uint32_t value)
{
    char digits[10];
    unsigned count = 0U;
    do
    {
        digits[count++] = (char)('0' + value % 10U);
        value /= 10U;
    } while (value != 0U);
    while (count != 0U)
    {
        at = append_char(at, digits[--count]);
    }
    return at;
}

void CallTrace_Drain(void)
{
    trace_record_t entry = {0U, 0, 0U};
    uint32_t key, lost = 0U;
    size_t at = 0U;
    drv_debug_status_t status;
    if (__get_IPSR() != 0U || __get_PRIMASK() != 0U || uart_output != 0U)
    {
        return;
    }
    key = __get_PRIMASK();
    __disable_irq();
    if (dropped != 0U && (uint32_t)(HAL_GetTick() - last_drop_ms) >= TRACE_PERIOD_MS)
    {
        lost = dropped;
        dropped = 0U;
        last_drop_ms = HAL_GetTick();
    }
    else if (tail != head)
    {
        entry = records[tail & (TRACE_CAPACITY - 1U)];
        ++tail;
    }
    else
    {
        __set_PRIMASK(key);
        return;
    }
    __set_PRIMASK(key);
    if (lost != 0U)
    {
        at = append_text(at, "T drop ");
        at = append_unsigned(at, lost);
    }
    else
    {
        at = append_unsigned(at, entry.ms);
        at = append_char(at, ' ');
        at = append_text(at, descriptions[entry.id].label);
        if ((descriptions[entry.id].flags & TRACE_HAS_VALUE) != 0U)
        {
            at = append_char(at, ' ');
            if (entry.value < 0)
            {
                at = append_char(at, '-');
            }
            at = append_unsigned(at, entry.value < 0 ? 0U - (uint32_t)entry.value : (uint32_t)entry.value);
        }
    }
    at = append_text(at, "\r\n");
    line[at] = '\0';
    /* Suppress only UART's own trace traffic, including its TX ISR. Motor/SPI
     * producers remain live while DebugCommand prints. One line per idle read
     * bounds UART use; pending command bytes are processed before trace output. */
    uart_output = 1U;
    status = DRV_DEBUG_Write((const uint8_t *)line, (uint32_t)at, TRACE_TX_TIMEOUT_MS);
    uart_output = 0U;
    if (status != DRV_DEBUG_OK)
    {
        key = __get_PRIMASK();
        __disable_irq();
        if (dropped != UINT32_MAX)
        {
            ++dropped;
        }
        __set_PRIMASK(key);
    }
}
#endif
