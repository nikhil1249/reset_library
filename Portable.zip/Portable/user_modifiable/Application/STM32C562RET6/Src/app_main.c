/* Standalone reference app_main. Merge the task creation block into the
 * existing baseline app_main; preserve its resources, managers and hooks. */
#include "app_main.h"
#include "app_config.h"
#include "task_tmc6460.h"
#include "task_debug.h"
static void app_main_error_trap(void)
{
    for (;;)
    {
    }
}
void app_main(void)
{
    TaskHandle_t motor = NULL, debug = NULL;
    static BaseType_t created;
    if (created || xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
    {
        app_main_error_trap();
    }
    created = pdTRUE;
    if (xTaskCreate(task_tmc6460_run, TASK_NAME_TMC6460, TASK_STACK_TMC6460_DRIVER, NULL, TASK_PRIO_TMC6460_DRIVER,
                    &motor) != pdPASS)
    {
        app_main_error_trap();
    }
    if (xTaskCreate(task_debug_run, TASK_NAME_DEBUG, TASK_STACK_DEBUG, NULL, TASK_PRIO_DEBUG, &debug) != pdPASS)
    {
        vTaskDelete(motor);
        app_main_error_trap();
    }
    vTaskStartScheduler();
    app_main_error_trap();
}
