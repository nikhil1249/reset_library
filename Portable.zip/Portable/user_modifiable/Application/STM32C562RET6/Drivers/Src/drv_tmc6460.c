#include "call_trace.h"
#include "drv_tmc6460.h"
#include "app_config.h"
#include "mx_spi2.h"
#include "mx_gpio_default.h"

#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"

#include <stddef.h>
#include <string.h>

void tmc6460_select(void)
{
    TRACE_ENTER(CT_F001);
    HAL_GPIO_WritePin(TMC_CS_PORT, TMC_CS_PIN, HAL_GPIO_PIN_RESET);
}
void tmc6460_deselect(void)
{
    TRACE_ENTER(CT_F002);
    HAL_GPIO_WritePin(TMC_CS_PORT, TMC_CS_PIN, HAL_GPIO_PIN_SET);
}

typedef struct
{
    hal_spi_handle_t *handle;
    SemaphoreHandle_t mutex;
    SemaphoreHandle_t done;
    volatile uint8_t error;
    uint8_t initialized;
    spi_interface_stats_t stats;
} spi_interface_context_t;

static spi_interface_context_t s_spi[SPI_INTERFACE_PORT_COUNT];

static spi_interface_context_t *spi_interface_get_context(spi_interface_port_t port)
{
    TRACE_ENTER(CT_F003);
    if ((uint32_t)port >= (uint32_t)SPI_INTERFACE_PORT_COUNT)
    {
        return NULL;
    }
    return &s_spi[(uint32_t)port];
}

static spi_interface_context_t *spi_interface_find_by_handle(hal_spi_handle_t *hspi)
{
    TRACE_ENTER(CT_F004);
    uint32_t i;
    for (i = 0U; i < (uint32_t)SPI_INTERFACE_PORT_COUNT; i++)
    {
        if ((s_spi[i].initialized != 0U) && (s_spi[i].handle == hspi))
        {
            return &s_spi[i];
        }
    }
    return NULL;
}

static void spi_interface_clear_semaphore(SemaphoreHandle_t semaphore)
{
    TRACE_ENTER(CT_F005);
    while (xSemaphoreTake(semaphore, (TickType_t)0U) == pdTRUE)
    {
        TRACE_EVENT(CT_S_D_CLR);
    }
}

spi_interface_status_t spi_interface_init(void)
{
    TRACE_ENTER(CT_F006);
#if (TMC_SPI_ENABLE != 0U)
    spi_interface_context_t *ctx = &s_spi[SPI_INTERFACE_PORT_TMC];
    memset(ctx, 0, sizeof(*ctx));
    ctx->handle = mx_spi2_gethandle();
    if (ctx->handle == NULL || ctx->handle->hdma_tx == NULL || ctx->handle->hdma_rx == NULL)
    {
        return SPI_INTERFACE_ERROR;
    }

    ctx->mutex = xSemaphoreCreateMutex();
    ctx->done = xSemaphoreCreateBinary();
    if ((ctx->mutex == NULL) || (ctx->done == NULL))
    {
        return SPI_INTERFACE_ERROR;
    }

    tmc6460_deselect();
    ctx->initialized = 1U;
    return SPI_INTERFACE_OK;
#else
    return SPI_INTERFACE_OK;
#endif
}

spi_interface_status_t spi_interface_transfer(spi_interface_port_t port, const uint8_t *tx_data, uint8_t *rx_data,
                                              uint32_t length, uint32_t timeout_ms)
{
    TRACE_ENTER(CT_F007);
#if (TMC_SPI_ENABLE != 0U)
    spi_interface_context_t *ctx = spi_interface_get_context(port);
    TickType_t ticks;
    hal_status_t hs;
    spi_interface_status_t result = SPI_INTERFACE_OK;

    if ((ctx == NULL) || (tx_data == NULL) || (rx_data == NULL) || (length == 0U))
    {
        return SPI_INTERFACE_INVALID_PARAM;
    }
    if (ctx->initialized == 0U)
    {
        return SPI_INTERFACE_NOT_INITIALIZED;
    }

    ticks = pdMS_TO_TICKS(timeout_ms);
    if (ticks == 0U)
    {
        ticks = 1U;
    }

    TRACE_EVENT(CT_S_M_WAIT);
    if (xSemaphoreTake(ctx->mutex, ticks) != pdTRUE)
    {
        TRACE_EVENT(CT_S_M_NO);
        ctx->stats.busy_count++;
        return SPI_INTERFACE_BUSY;
    }

    TRACE_EVENT(CT_S_M_OK);
    ctx->error = 0U;
    spi_interface_clear_semaphore(ctx->done);

    /* Preserve the proven external-CS timing: CSN goes LOW immediately before
     * the DMA/IT SPI engine starts, with no task switch in between. */
    TRACE_EVENT(CT_S_TX_START);
    taskENTER_CRITICAL();
    tmc6460_select();
    hs = HAL_SPI_TransmitReceive_DMA(ctx->handle, tx_data, rx_data, length);
    taskEXIT_CRITICAL();

    if (hs != HAL_OK)
    {
        tmc6460_deselect();
        if (xSemaphoreGive(ctx->mutex) == pdTRUE)
        {
            TRACE_EVENT(CT_S_M_REL);
        }
        else
        {
            TRACE_EVENT(CT_S_M_BAD);
        }
        if (hs == HAL_BUSY)
        {
            ctx->stats.busy_count++;
        }
        else
        {
            ctx->stats.errors++;
        }
        return (hs == HAL_BUSY) ? SPI_INTERFACE_BUSY : SPI_INTERFACE_ERROR;
    }

    TRACE_EVENT(CT_S_D_WAIT);
    if (xSemaphoreTake(ctx->done, ticks) != pdTRUE)
    {
        (void)HAL_SPI_Abort(ctx->handle);
        tmc6460_deselect();
        TRACE_EVENT(CT_S_D_TO);
        ctx->stats.timeouts++;
        result = SPI_INTERFACE_TIMEOUT;
    }
    else if (ctx->error != 0U)
    {
        TRACE_EVENT(CT_S_D_OK);
        /* Quiesce the HAL/DMA engine before returning caller-owned buffers. */
        (void)HAL_SPI_Abort(ctx->handle);
        tmc6460_deselect();
        ctx->stats.errors++;
        result = SPI_INTERFACE_ERROR;
    }
    else
    {
        TRACE_EVENT(CT_S_D_OK);
        ctx->stats.transfers++;
    }

    if (xSemaphoreGive(ctx->mutex) == pdTRUE)
    {
        TRACE_EVENT(CT_S_M_REL);
    }
    else
    {
        TRACE_EVENT(CT_S_M_BAD);
    }
    return result;
#else
    (void)port;
    (void)tx_data;
    (void)rx_data;
    (void)length;
    (void)timeout_ms;
    return SPI_INTERFACE_NOT_INITIALIZED;
#endif
}

void spi_interface_get_stats(spi_interface_port_t port, spi_interface_stats_t *stats)
{
    TRACE_ENTER(CT_F009);
    spi_interface_context_t *ctx = spi_interface_get_context(port);
    if (stats == NULL)
    {
        return;
    }
    memset(stats, 0, sizeof(*stats));
    if ((ctx == NULL) || (ctx->initialized == 0U))
    {
        return;
    }
    *stats = ctx->stats;
}

void drv_tmc6460_on_complete(hal_spi_handle_t *hspi)
{
    TRACE_ENTER(CT_F010);
#if (TMC_SPI_ENABLE != 0U)
    spi_interface_context_t *ctx = spi_interface_find_by_handle(hspi);
    if (ctx != NULL)
    {
        BaseType_t hpw = pdFALSE;
        TRACE_EVENT(CT_S_TX_DONE);
        tmc6460_deselect();
        if (xSemaphoreGiveFromISR(ctx->done, &hpw) == pdTRUE)
        {
            TRACE_EVENT(CT_S_D_GIVE);
        }
        else
        {
            TRACE_EVENT(CT_S_D_BAD);
        }
        portYIELD_FROM_ISR(hpw);
    }
#else
    (void)hspi;
#endif
}

void drv_tmc6460_on_error(hal_spi_handle_t *hspi)
{
    TRACE_ENTER(CT_F011);
#if (TMC_SPI_ENABLE != 0U)
    spi_interface_context_t *ctx = spi_interface_find_by_handle(hspi);
    if (ctx != NULL)
    {
        BaseType_t hpw = pdFALSE;
        TRACE_EVENT(CT_S_ERR);
        ctx->error = 1U;
        tmc6460_deselect();
        if (xSemaphoreGiveFromISR(ctx->done, &hpw) == pdTRUE)
        {
            TRACE_EVENT(CT_S_D_GIVE);
        }
        else
        {
            TRACE_EVENT(CT_S_D_BAD);
        }
        portYIELD_FROM_ISR(hpw);
    }
#else
    (void)hspi;
#endif
}
