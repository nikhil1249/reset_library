#include "drv_uart.h"
#include "app_config.h"
#include "mx_usart2.h"

#include "FreeRTOS.h"
#include "semphr.h"
#include "stream_buffer.h"
#include "task.h"

#include <stddef.h>
#include <string.h>

typedef struct
{
    hal_uart_handle_t *handle;
    SemaphoreHandle_t mutex;
    SemaphoreHandle_t tx_done;
    StreamBufferHandle_t rx_stream;
    uint8_t buffered_rx_byte;
    volatile uint8_t error;
    volatile uint8_t rx_restart;
    volatile uint8_t buffered_rx_enabled;
    uint8_t initialized;
    drv_debug_stats_t stats;
} drv_debug_context_t;

static drv_debug_context_t s_uart;

static drv_debug_context_t *DRV_DEBUG_FindByHandle(hal_uart_handle_t *h)
{
    return s_uart.initialized && s_uart.handle == h ? &s_uart : NULL;
}

static void DRV_DEBUG_ClearSemaphore(SemaphoreHandle_t semaphore)
{
    while (xSemaphoreTake(semaphore, (TickType_t)0U) == pdTRUE)
    {
    }
}

static drv_debug_status_t DRV_DEBUG_Register(hal_uart_handle_t *handle)
{
    drv_debug_context_t *ctx = &s_uart;
    if ((ctx == NULL) || (handle == NULL))
    {
        return DRV_DEBUG_INVALID_PARAM;
    }

    memset(ctx, 0, sizeof(*ctx));
    ctx->handle = handle;
    ctx->mutex = xSemaphoreCreateMutex();
    ctx->tx_done = xSemaphoreCreateBinary();
    if ((ctx->mutex == NULL) || (ctx->tx_done == NULL))
    {
        return DRV_DEBUG_ERROR;
    }
    ctx->initialized = 1U;
    return DRV_DEBUG_OK;
}

drv_debug_status_t DRV_DEBUG_Init(void)
{
    drv_debug_status_t status;
    status = DRV_DEBUG_Register(mx_usart2_uart_gethandle());
    if (status != DRV_DEBUG_OK)
    {
        return status;
    }
    return DRV_DEBUG_OK;
}

static drv_debug_status_t DRV_DEBUG_Lock(drv_debug_context_t *ctx, uint32_t timeout_ms)
{
    TickType_t ticks = pdMS_TO_TICKS(timeout_ms);
    if (ticks == 0U)
    {
        ticks = 1U;
    }
    return (xSemaphoreTake(ctx->mutex, ticks) == pdTRUE) ? DRV_DEBUG_OK : DRV_DEBUG_BUSY;
}

static void DRV_DEBUG_Unlock(drv_debug_context_t *ctx)
{
    (void)xSemaphoreGive(ctx->mutex);
}

static drv_debug_status_t DRV_DEBUG_WaitCompletion(drv_debug_context_t *ctx, SemaphoreHandle_t semaphore,
                                                   uint32_t timeout_ms)
{
    TickType_t ticks = pdMS_TO_TICKS(timeout_ms);
    if (ticks == 0U)
    {
        ticks = 1U;
    }

    if (xSemaphoreTake(semaphore, ticks) != pdTRUE)
    {
        /* A console TX timeout must not silently cancel command reception. */
        (void)HAL_UART_AbortTransmit(ctx->handle);
        ctx->stats.timeouts++;
        return DRV_DEBUG_TIMEOUT;
    }
    if (ctx->error != 0U)
    {
        /* An RX error can wake a concurrent console writer. Quiesce its
         * transfer before returning ownership of the caller's buffer. */
        (void)HAL_UART_AbortTransmit(ctx->handle);
        ctx->stats.errors++;
        return DRV_DEBUG_ERROR;
    }
    return DRV_DEBUG_OK;
}

drv_debug_status_t DRV_DEBUG_Write(const uint8_t *data, uint32_t length, uint32_t timeout_ms)
{
    drv_debug_context_t *ctx = &s_uart;
    drv_debug_status_t result;
    hal_status_t hs;

    if ((ctx == NULL) || (data == NULL) || (length == 0U))
    {
        return DRV_DEBUG_INVALID_PARAM;
    }
    if (ctx->initialized == 0U)
    {
        return DRV_DEBUG_NOT_INITIALIZED;
    }

    result = DRV_DEBUG_Lock(ctx, timeout_ms);
    if (result != DRV_DEBUG_OK)
    {
        return result;
    }

    ctx->error = 0U;
    DRV_DEBUG_ClearSemaphore(ctx->tx_done);
    hs = HAL_UART_Transmit_IT(ctx->handle, data, length);
    if (hs != HAL_OK)
    {
        DRV_DEBUG_Unlock(ctx);
        return (hs == HAL_BUSY) ? DRV_DEBUG_BUSY : DRV_DEBUG_ERROR;
    }

    result = DRV_DEBUG_WaitCompletion(ctx, ctx->tx_done, timeout_ms);
    if (result == DRV_DEBUG_OK)
    {
        ctx->stats.tx_transfers++;
    }
    DRV_DEBUG_Unlock(ctx);
    return result;
}

static hal_status_t DRV_DEBUG_ArmBufferedRx(drv_debug_context_t *ctx)
{
    return HAL_UART_Receive_IT(ctx->handle, &ctx->buffered_rx_byte, 1U);
}

drv_debug_status_t DRV_DEBUG_StartBufferedRx(void)
{
    drv_debug_context_t *ctx = &s_uart;
    hal_status_t hs;

    if (ctx == NULL)
    {
        return DRV_DEBUG_INVALID_PARAM;
    }
    if (ctx->initialized == 0U)
    {
        return DRV_DEBUG_NOT_INITIALIZED;
    }
    if (ctx->buffered_rx_enabled != 0U)
    {
        return DRV_DEBUG_OK;
    }

    ctx->rx_stream = xStreamBufferCreate((size_t)DEBUG_RX_STREAM_SIZE, 1U);
    if (ctx->rx_stream == NULL)
    {
        return DRV_DEBUG_ERROR;
    }

    ctx->error = 0U;
    ctx->buffered_rx_enabled = 1U;
    hs = DRV_DEBUG_ArmBufferedRx(ctx);
    if (hs != HAL_OK)
    {
        ctx->buffered_rx_enabled = 0U;
        vStreamBufferDelete(ctx->rx_stream);
        ctx->rx_stream = NULL;
        return (hs == HAL_BUSY) ? DRV_DEBUG_BUSY : DRV_DEBUG_ERROR;
    }
    return DRV_DEBUG_OK;
}

uint32_t DRV_DEBUG_ReadBuffered(uint8_t *data, uint32_t max_length, uint32_t timeout_ms)
{
    drv_debug_context_t *ctx = &s_uart;
    TickType_t ticks;
    size_t received;

    if ((ctx == NULL) || (data == NULL) || (max_length == 0U) || (ctx->initialized == 0U) ||
        (ctx->buffered_rx_enabled == 0U) || (ctx->rx_stream == NULL))
    {
        return 0U;
    }

    /* Restart from task context after RX framing/overrun error. The command task
     * is the single reader/owner of this recovery path. */
    if (ctx->rx_restart != 0U)
    {
        (void)HAL_UART_AbortReceive(ctx->handle);
        ctx->rx_restart = 0U;
        if (DRV_DEBUG_ArmBufferedRx(ctx) != HAL_OK)
        {
            ctx->rx_restart = 1U;
            vTaskDelay(1U);
            return 0U;
        }
    }
    ticks = pdMS_TO_TICKS(timeout_ms);
    if ((timeout_ms != 0U) && (ticks == 0U))
    {
        ticks = 1U;
    }
    received = xStreamBufferReceive(ctx->rx_stream, data, (size_t)max_length, ticks);
    return (uint32_t)received;
}

void DRV_DEBUG_GetStats(drv_debug_stats_t *stats)
{
    drv_debug_context_t *ctx = &s_uart;
    if (stats == NULL)
    {
        return;
    }
    memset(stats, 0, sizeof(*stats));
    if ((ctx == NULL) || (ctx->initialized == 0U))
    {
        return;
    }
    *stats = ctx->stats;
    if (ctx->rx_stream != NULL)
    {
        stats->stream_bytes_available = (uint32_t)xStreamBufferBytesAvailable(ctx->rx_stream);
    }
}

void drv_debug_on_tx_complete(hal_uart_handle_t *huart)
{
    drv_debug_context_t *ctx = DRV_DEBUG_FindByHandle(huart);
    BaseType_t hpw = pdFALSE;
    if (ctx != NULL)
    {
        (void)xSemaphoreGiveFromISR(ctx->tx_done, &hpw);
        portYIELD_FROM_ISR(hpw);
    }
}

void drv_debug_on_rx_complete(hal_uart_handle_t *huart, uint32_t size_byte, hal_uart_rx_event_types_t rx_event)
{
    drv_debug_context_t *ctx = DRV_DEBUG_FindByHandle(huart);
    BaseType_t hpw = pdFALSE;
    size_t sent;
    if (rx_event != HAL_UART_RX_EVENT_TC || size_byte != 1U)
    {
        return;
    }

    if (ctx == NULL)
    {
        return;
    }

    if ((ctx->buffered_rx_enabled != 0U) && (ctx->rx_stream != NULL))
    {
        sent = xStreamBufferSendFromISR(ctx->rx_stream, &ctx->buffered_rx_byte, 1U, &hpw);
        ctx->stats.buffered_rx_bytes += (uint32_t)sent;
        ctx->stats.buffered_rx_dropped += (1U - (uint32_t)sent);
        if (DRV_DEBUG_ArmBufferedRx(ctx) != HAL_OK)
        {
            ctx->rx_restart = 1U;
            ctx->error = 1U;
            ctx->stats.errors++;
        }
        portYIELD_FROM_ISR(hpw);
        return;
    }

    portYIELD_FROM_ISR(hpw);
}

void drv_debug_on_error(hal_uart_handle_t *huart)
{
    drv_debug_context_t *ctx = DRV_DEBUG_FindByHandle(huart);
    BaseType_t hpw = pdFALSE;
    if (ctx != NULL)
    {
        ctx->error = 1U;
        if (ctx->buffered_rx_enabled)
        {
            ctx->rx_restart = 1U;
        }
        ctx->stats.errors++;
        (void)xSemaphoreGiveFromISR(ctx->tx_done, &hpw);
        portYIELD_FROM_ISR(hpw);
    }
}

void drv_debug_write_text(const char *text)
{
    if (text != NULL)
    {
        (void)DRV_DEBUG_Write((const uint8_t *)text, (uint32_t)strlen(text), DEBUG_UART_TIMEOUT_MS);
    }
}
