#ifndef DRV_TMC6460_H
#define DRV_TMC6460_H

#include "stm32_hal.h"
#include <stdint.h>

typedef enum
{
    SPI_INTERFACE_OK = 0,
    SPI_INTERFACE_ERROR,
    SPI_INTERFACE_BUSY,
    SPI_INTERFACE_TIMEOUT,
    SPI_INTERFACE_INVALID_PARAM,
    SPI_INTERFACE_NOT_INITIALIZED
} spi_interface_status_t;

typedef enum
{
    SPI_INTERFACE_PORT_TMC = 0,
    SPI_INTERFACE_PORT_COUNT
} spi_interface_port_t;

typedef struct
{
    uint32_t transfers;
    uint32_t timeouts;
    uint32_t errors;
    uint32_t busy_count;
} spi_interface_stats_t;

spi_interface_status_t spi_interface_init(void);
spi_interface_status_t spi_interface_transfer(spi_interface_port_t port, const uint8_t *tx_data, uint8_t *rx_data,
                                              uint32_t length, uint32_t timeout_ms);
void spi_interface_get_stats(spi_interface_port_t port, spi_interface_stats_t *stats);

void tmc6460_select(void);
void tmc6460_deselect(void);
void drv_tmc6460_on_complete(hal_spi_handle_t *hspi);
void drv_tmc6460_on_error(hal_spi_handle_t *hspi);
#endif /* DRV_TMC6460_H */
