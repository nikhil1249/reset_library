#ifndef DRV_UART_H
#define DRV_UART_H
#include "stm32_hal.h"
#include <stdint.h>
typedef enum
{
    DRV_DEBUG_OK = 0,
    DRV_DEBUG_ERROR,
    DRV_DEBUG_BUSY,
    DRV_DEBUG_TIMEOUT,
    DRV_DEBUG_INVALID_PARAM,
    DRV_DEBUG_NOT_INITIALIZED
} drv_debug_status_t;
typedef struct
{
    uint32_t tx_transfers, rx_transfers, timeouts, errors;
    uint32_t buffered_rx_bytes, buffered_rx_dropped, stream_bytes_available;
} drv_debug_stats_t;
drv_debug_status_t DRV_DEBUG_Init(void);
drv_debug_status_t DRV_DEBUG_StartBufferedRx(void);
drv_debug_status_t DRV_DEBUG_Write(const uint8_t *, uint32_t, uint32_t);
uint32_t DRV_DEBUG_ReadBuffered(uint8_t *, uint32_t, uint32_t);
void DRV_DEBUG_GetStats(drv_debug_stats_t *);
void drv_debug_write_text(const char *);
/* Called only by the existing HAL callbacks in drv_uart.c. */
void drv_debug_on_tx_complete(hal_uart_handle_t *);
void drv_debug_on_rx_complete(hal_uart_handle_t *, uint32_t, hal_uart_rx_event_types_t);
void drv_debug_on_error(hal_uart_handle_t *);
#endif
