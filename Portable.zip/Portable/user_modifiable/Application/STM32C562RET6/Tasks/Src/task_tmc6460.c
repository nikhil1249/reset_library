#include "task_tmc6460.h"
#include "task_debug.h"
#include "drv_tmc6460.h"
#include "svc_motor_control.h"
#include "app_config.h"
static TaskHandle_t motor_task;
static volatile int motor_state;
TaskHandle_t task_tmc6460_get_handle(void)
{
    return motor_task;
}
int task_tmc6460_get_state(void)
{
    return motor_state;
}
void task_tmc6460_run(void *argument)
{
    uint32_t phase = 0U;
    TickType_t last_wake;
    (void)argument;
    motor_task = xTaskGetCurrentTaskHandle();
    /* Debug owns its UART init; wait without starving its lower priority task. */
    while (task_debug_get_state() == 0)
    {
        vTaskDelay(1U);
    }
    if (task_debug_get_state() < 0 || spi_interface_init() != SPI_INTERFACE_OK || svc_motor_control_init() != 0)
    {
        motor_state = -1;
        for (;;)
        {
            vTaskDelay(pdMS_TO_TICKS(1000U));
        }
    }
    motor_state = 1;
    vTaskDelay(pdMS_TO_TICKS(TMC_STARTUP_DELAY_MS));
    last_wake = xTaskGetTickCount();
    for (;;)
    {
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
        /* Endpoint/stop processing cannot be starved by a command backlog. */
        (void)svc_motor_control_sample();
        (void)svc_motor_control_process_next(0U);
        vTaskDelayUntil(&last_wake, svc_motor_control_sample_period(&phase));
#else
        while (svc_motor_control_process_next(0U) == pdTRUE)
        {
            last_wake = xTaskGetTickCount();
            phase = 0U;
        }
        if (svc_motor_control_sample() == pdTRUE)
        {
            vTaskDelayUntil(&last_wake, svc_motor_control_sample_period(&phase));
        }
        else
        {
            (void)svc_motor_control_process_next(portMAX_DELAY);
            last_wake = xTaskGetTickCount();
            phase = 0U;
        }
#endif
    }
}
