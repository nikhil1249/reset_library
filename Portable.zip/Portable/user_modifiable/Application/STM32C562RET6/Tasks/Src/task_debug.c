#include "call_trace.h"
#include "task_debug.h"
#include "task_tmc6460.h"
#include "drv_uart.h"
#include "app_config.h"
#include "svc_motor_control.h"
#include "actuator_sr.h"
#include "runtime_memory.h"
#include <stddef.h>
static TaskHandle_t command_task;
static volatile int debug_state;
TaskHandle_t task_debug_get_handle(void)
{
    TRACE_ENTER(CT_F128);
    return command_task;
}
int task_debug_get_state(void)
{
    TRACE_ENTER(CT_F129);
    return debug_state;
}
static void debug_print_help(void)
{
    TRACE_ENTER(CT_F130);
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
    drv_debug_write_text(
        "SR: A/B/C=profile V/W=manual Z=HOLD G=calibrate X/Y=calibrated CW/CCW R=DIAG M=MEM\r\nG requires physical zero. Manual V/W invalidates calibration; W needs Z at zero.\r\n");
#else
    drv_debug_write_text("A=10kg B=20kg C=35kg | V/W=raw manual | Z=HOLD | R=DIAG M=MEM ?=HELP\r\n"
#if ACTUATOR_NSR_AUTO_CALIBRATION
                         "G=AUTO CALIBRATION\r\n"
#endif
#if ACTUATOR_NSR_SOFT_STALL
                         "X=SOFT CW->90 Y=SOFT CCW->0 P=SOFT CONFIG\r\n"
                         "Stored ACT_CAL_x_* enables X/Y after reset; first X/Y softly anchors position.\r\n"
#endif
#if ACTUATOR_NSR_AUTO_CALIBRATION || ACTUATOR_NSR_SOFT_STALL
                         "During a long operation, Z aborts to HOLD.\r\n"
#endif
    );
#endif
}
void task_debug_run(void *argument)
{
    TRACE_ENTER(CT_F131);
#if (DEBUG_UART_ENABLE != 0U)
    uint8_t ch;
    const actuator_profile_t *profile;
    (void)argument;
    command_task = xTaskGetCurrentTaskHandle();

    if (DRV_DEBUG_Init() != DRV_DEBUG_OK || DRV_DEBUG_StartBufferedRx() != DRV_DEBUG_OK)
    {
        debug_state = -1;
        for (;;)
        {
            vTaskDelay(pdMS_TO_TICKS(1000U));
        }
    }
    debug_state = 1;
    while (task_tmc6460_get_state() == 0)
    {
        vTaskDelay(1U);
    }
    if (task_tmc6460_get_state() < 0)
    {
        drv_debug_write_text("ERR: MOTOR TASK INIT FAILED; reset after correcting configuration/heap\r\n");
        for (;;)
        {
            vTaskDelay(pdMS_TO_TICKS(1000U));
        }
    }

    drv_debug_write_text("\r\nActuator - SPI DMA / USART2 IRQ\r\nTMC interface: " TMC_INTERFACE_NAME "\r\n");
    debug_print_help();

    for (;;)
    {
        if (DRV_DEBUG_ReadBuffered(&ch, 1U, TRACE_RX_WAIT_MS) == 0U)
        {
            TRACE_PUMP();
            continue;
        }

        if ((ch >= (uint8_t)'a') && (ch <= (uint8_t)'z'))
        {
            ch = (uint8_t)(ch - ((uint8_t)'a' - (uint8_t)'A'));
        }

        TRACE_COMMAND(ch);
#if ACTUATOR_TYPE == ACTUATOR_TYPE_SR
        /* Reject busy commands in DebugCommand, never block the motor poll
         * on a UART error message. The motor owner rechecks on dequeue. */
        if (ch == 'A' || ch == 'B' || ch == 'C' || ch == 'G' || ch == 'V' || ch == 'W' || ch == 'X' || ch == 'Y')
        {
            uint32_t state = g_status.sr_state;
            if (state != SR_BOOT && state != SR_READY && state != SR_FAULT)
            {
                drv_debug_write_text("SR: busy; Z=HOLD before another command\r\n");
                continue;
            }
            if (ch != 'A' && ch != 'B' && ch != 'C' && (!g_status.actuator_initialized || state == SR_FAULT))
            {
                drv_debug_write_text("SR: select A/B/C first; inspect R if faulted\r\n");
                continue;
            }
            if ((ch == 'X' || ch == 'Y') && !g_status.calibration_valid)
            {
                drv_debug_write_text("SR: X/Y locked; complete G from physical zero first\r\n");
                continue;
            }
        }
        switch (ch)
        {
        case 'A':
        case 'B':
        case 'C':
            profile = ActuatorProfile_FromCommand((char)ch);
            if (profile != NULL &&
                svc_motor_control_queue_command(MOTOR_COMMAND_SELECT_PROFILE, profile->type) != pdPASS)
            {
                drv_debug_write_text("ERR: COMMAND QUEUE FULL\r\n");
            }
            break;
        case 'V':
        case 'W':
        case 'X':
        case 'Y':
        case 'G':
        {
            motor_command_type_t command = ch == 'V'   ? MOTOR_COMMAND_RUN_CW
                                           : ch == 'W' ? MOTOR_COMMAND_RUN_CCW
                                           : ch == 'X' ? MOTOR_COMMAND_SOFT_CW
                                           : ch == 'Y' ? MOTOR_COMMAND_SOFT_CCW
                                                       : MOTOR_COMMAND_AUTO_CALIBRATE;
            if (svc_motor_control_queue_command(command, g_status.actuator_type) != pdPASS)
            {
                drv_debug_write_text("ERR: COMMAND QUEUE FULL\r\n");
            }
            break;
        }
        case 'Z':
            svc_motor_control_request_abort();
            break;
        case 'R':
            ActuatorSR_PrintStatus();
            break;
        case 'M':
        {
            runtime_memory_snapshot_t mem;
            char report[360];
            RuntimeMemory_Get(&mem);
            if (RuntimeMemory_FormatDetailed(report, sizeof(report), &mem) > 0)
            {
                drv_debug_write_text(report);
            }
            break;
        }
        case '?':
        case 'H':
            debug_print_help();
            break;
        case '\r':
        case '\n':
        case ' ':
            break;
        default:
            drv_debug_write_text("ERR: UNKNOWN COMMAND\r\n");
            break;
        }
#else
        /* Long calibration/soft-stall operations execute synchronously in the
         * sole-owner MotorServiceTask. Z is therefore a direct abort flag and
         * must not be queued behind the active operation. */
#if ACTUATOR_NSR_AUTO_CALIBRATION || ACTUATOR_NSR_SOFT_STALL
        if (
#if ACTUATOR_NSR_AUTO_CALIBRATION
            g_status.calibration_active != 0U ||
#endif
#if ACTUATOR_NSR_SOFT_STALL
            g_status.soft_stall_active != 0U ||
#endif
            0)
        {
            if (ch == (uint8_t)'Z')
            {
#if ACTUATOR_NSR_AUTO_CALIBRATION
                if (g_status.calibration_active != 0U)
                {
                    svc_motor_control_request_abort();
                    drv_debug_write_text("CAL ABORT REQUESTED\r\n");
                }
#if ACTUATOR_NSR_SOFT_STALL
                else
#endif
#endif
#if ACTUATOR_NSR_SOFT_STALL
                {
                    svc_motor_control_request_abort();
                    drv_debug_write_text("SOFT ABORT REQUESTED\r\n");
                }
#endif
            }
#if ACTUATOR_NSR_SOFT_STALL
            else if (ch == (uint8_t)'P')
            {
                svc_motor_control_print_soft_stall_config();
            }
#endif
            else if (ch == (uint8_t)'M')
            {
                runtime_memory_snapshot_t mem;
                char mem_message[360];
                int mem_len;
                RuntimeMemory_Get(&mem);
                mem_len = RuntimeMemory_FormatDetailed(mem_message, sizeof(mem_message), &mem);
                if (mem_len > 0)
                {
                    drv_debug_write_text(mem_message);
                }
            }
            else if ((ch == (uint8_t)'?') || (ch == (uint8_t)'H'))
            {
                drv_debug_write_text("BUSY: Z=ABORT/HOLD"
#if ACTUATOR_NSR_SOFT_STALL
                                     ", P=SOFT CONFIG"
#endif
                                     ". Other motor commands are locked.\r\n");
            }
            else if ((ch != (uint8_t)'\r') && (ch != (uint8_t)'\n') && (ch != (uint8_t)' '))
            {
                drv_debug_write_text("ERR: CAL/SOFT MOVE ACTIVE; Z=ABORT\r\n");
            }
            continue;
        }

#endif
        profile = ActuatorProfile_FromCommand((char)ch);
        if (profile != NULL)
        {
            if (svc_motor_control_queue_command(MOTOR_COMMAND_SELECT_PROFILE, profile->type) == pdPASS)
            {
                drv_debug_write_text("PROFILE INIT REQUESTED\r\n");
            }
            else
            {
                drv_debug_write_text("ERR: COMMAND QUEUE FULL\r\n");
            }
            continue;
        }

        switch (ch)
        {
        case (uint8_t)'V':
            if (g_status.actuator_initialized == 0U)
            {
                drv_debug_write_text("ERR: SELECT A/B/C FIRST\r\n");
            }
            else if (svc_motor_control_queue_command(MOTOR_COMMAND_RUN_CW, g_status.actuator_type) == pdPASS)
            {
                drv_debug_write_text("CW REQUESTED\r\n");
            }
            break;

        case (uint8_t)'W':
            if (g_status.actuator_initialized == 0U)
            {
                drv_debug_write_text("ERR: SELECT A/B/C FIRST\r\n");
            }
            else if (svc_motor_control_queue_command(MOTOR_COMMAND_RUN_CCW, g_status.actuator_type) == pdPASS)
            {
                drv_debug_write_text("CCW REQUESTED\r\n");
            }
            break;

        case (uint8_t)'Z':
            if (g_status.actuator_initialized == 0U)
            {
                drv_debug_write_text("ERR: SELECT A/B/C FIRST\r\n");
            }
            else if (svc_motor_control_queue_command(MOTOR_COMMAND_STOP_HOLD, g_status.actuator_type) == pdPASS)
            {
                drv_debug_write_text("STOP/HOLD REQUESTED\r\n");
            }
            break;

#if ACTUATOR_NSR_AUTO_CALIBRATION
        case (uint8_t)'G':
            if (g_status.actuator_initialized == 0U)
            {
                drv_debug_write_text("ERR: SELECT A/B/C FIRST\r\n");
            }
            else if (svc_motor_control_queue_command(MOTOR_COMMAND_AUTO_CALIBRATE, g_status.actuator_type) == pdPASS)
            {
                drv_debug_write_text("AUTO CALIBRATION REQUESTED\r\n");
            }
            break;

#endif
#if ACTUATOR_NSR_SOFT_STALL
        case (uint8_t)'X':
            if (g_status.actuator_initialized == 0U)
            {
                drv_debug_write_text("ERR: SELECT A/B/C FIRST\r\n");
            }
            else if (g_status.calibration_params_loaded == 0U)
            {
                drv_debug_write_text("ERR: NO STORED CAL PARAMS. "
#if ACTUATOR_NSR_AUTO_CALIBRATION
                                     "RUN G ONCE, "
#endif
                                     "COPY ACT_CAL_x_* MACROS, REBUILD\r\n");
            }
            else if (svc_motor_control_queue_command(MOTOR_COMMAND_SOFT_CW, g_status.actuator_type) == pdPASS)
            {
                drv_debug_write_text("SOFT CW REQUESTED\r\n");
            }
            break;

        case (uint8_t)'Y':
            if (g_status.actuator_initialized == 0U)
            {
                drv_debug_write_text("ERR: SELECT A/B/C FIRST\r\n");
            }
            else if (g_status.calibration_params_loaded == 0U)
            {
                drv_debug_write_text("ERR: NO STORED CAL PARAMS. "
#if ACTUATOR_NSR_AUTO_CALIBRATION
                                     "RUN G ONCE, "
#endif
                                     "COPY ACT_CAL_x_* MACROS, REBUILD\r\n");
            }
            else if (svc_motor_control_queue_command(MOTOR_COMMAND_SOFT_CCW, g_status.actuator_type) == pdPASS)
            {
                drv_debug_write_text("SOFT CCW REQUESTED\r\n");
            }
            break;

        case (uint8_t)'P':
            svc_motor_control_print_soft_stall_config();
            break;

#endif
        case (uint8_t)'R':
            if (svc_motor_control_queue_command(MOTOR_COMMAND_REFRESH_DIAGNOSTICS, g_status.actuator_type) == pdPASS)
            {
                drv_debug_write_text("DIAG REFRESH REQUESTED\r\n");
            }
            break;

        case (uint8_t)'M':
        {
            runtime_memory_snapshot_t mem;
            char mem_message[360];
            int mem_len;
            RuntimeMemory_Get(&mem);
            mem_len = RuntimeMemory_FormatDetailed(mem_message, sizeof(mem_message), &mem);
            if (mem_len > 0)
            {
                drv_debug_write_text(mem_message);
            }
            break;
        }

        case (uint8_t)'D':
        case (uint8_t)'E':
            drv_debug_write_text("D/E PROFILE RESERVED - ADD VALUES IN actuator_profile.c\r\n");
            break;

        case (uint8_t)'?':
        case (uint8_t)'H':
            debug_print_help();
            break;

        case (uint8_t)'\r':
        case (uint8_t)'\n':
        case (uint8_t)' ':
            break;

        default:
            drv_debug_write_text("ERR: UNKNOWN COMMAND\r\n");
            break;
        }
#endif
    }
#else
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(1000U));
    }
#endif
}
