#ifndef TASK_DEBUG_H
#define TASK_DEBUG_H
#include "FreeRTOS.h"
#include "task.h"
void task_debug_run(void *argument);
int task_debug_get_state(void); /* 0 starting, 1 ready, -1 init failure */
TaskHandle_t task_debug_get_handle(void);
#endif
