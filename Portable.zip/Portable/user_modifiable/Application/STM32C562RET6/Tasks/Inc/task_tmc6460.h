#ifndef TASK_TMC6460_H
#define TASK_TMC6460_H
#include "FreeRTOS.h"
#include "task.h"
void task_tmc6460_run(void *argument);
int task_tmc6460_get_state(void); /* 0 starting, 1 ready, -1 init failure */
TaskHandle_t task_tmc6460_get_handle(void);
#endif
